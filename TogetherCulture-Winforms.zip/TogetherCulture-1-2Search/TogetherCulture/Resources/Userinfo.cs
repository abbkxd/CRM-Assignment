﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace TogetherCulture.Resources
{
    public partial class Userinfo : Form
    {
        private readonly string _connectionString = "Server=localhost;Database=usercred;User Id=root;";

        private string _usernamefk;

        public Userinfo(string username)
        {
            InitializeComponent();
            _usernamefk = username; 
        }

        public Userinfo()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Signup_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void tbPhno_TextChanged(object sender, EventArgs e)
        {
        }

        private void tbAddressBuildNo_TextChanged(object sender, EventArgs e)
        {

        }

        private void btSubmit_Click(object sender, EventArgs e)
        {

            string username = _usernamefk;
            string Fname = tbFname.Text.Trim();
            string Lname = tbLname.Text.Trim();
            DateTime UserDOB = dTDOB.Value;
            int BuildingNo;
            string PhNo = tbPhno.Text.Trim();
            string Strname = tbAddressSN.Text.Trim();
            string City = tbAddresscity.Text.Trim();
            string PCode = tbAddressPC.Text.Trim();

            if (!long.TryParse(PhNo, out _)) 
            {
                MessageBox.Show("Invalid phone number. Please enter only numeric values.");
                return;
            }

            if (!int.TryParse(tbAddressBuildNo.Text, out BuildingNo))
            {
                MessageBox.Show("Invalid building number.");
                return;
            }

            bool userSaved = SaveUserinfo(username, Fname, Lname, UserDOB, PhNo);
            bool addressSaved = SaveUserAddr(username, BuildingNo, Strname, City, PCode);

            if (userSaved && addressSaved)
            {
                MessageBox.Show("User information saved successfully.");
                this.Hide();

                UserSub userSub = new UserSub(username);
                userSub.Show();
            }
            else
            {
                MessageBox.Show("Failed to save user information.");
            }
        }

        private void dTDOB_ValueChanged(object sender, EventArgs e)
        {

        }

        private bool SaveUserinfo(string username, string Fname, string Lname, DateTime UserDOB, string PhNo)
        {
            try
            {
                using (MySqlConnection connection = new MySqlConnection(_connectionString))
                {
                    connection.Open();
                    string query = "INSERT INTO Userinfo (Username, FName, LName, DOB, Phno) VALUES (@username, @FName, @LName, @DOB, @PhoneNumber)";

                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@username", username);
                        command.Parameters.AddWithValue("@FName", Fname);
                        command.Parameters.AddWithValue("@LName", Lname);
                        command.Parameters.AddWithValue("@DOB", UserDOB);
                        command.Parameters.AddWithValue("@PhoneNumber", PhNo);
                        command.ExecuteNonQuery();
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                return false;
            }
        }

        private bool SaveUserAddr(string username, int BuildingNo, string Strname, string City, string PCode)
        {
            try
            {
                using (MySqlConnection connection = new MySqlConnection(_connectionString))
                {
                    connection.Open();
                    string query = "INSERT INTO UserAddr (Username, BuildingNo, Strname, City, PCode) VALUES (@username, @BuildingNo, @Strname, @City, @PCode)";

                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@username", username);
                        command.Parameters.AddWithValue("@BuildingNo", BuildingNo);
                        command.Parameters.AddWithValue("@Strname", Strname);
                        command.Parameters.AddWithValue("@City", City);
                        command.Parameters.AddWithValue("@PCode", PCode);
                        command.ExecuteNonQuery();
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                return false;
            }
        }

        private void tbLname_TextChanged(object sender, EventArgs e)
        {

        }
    }
}