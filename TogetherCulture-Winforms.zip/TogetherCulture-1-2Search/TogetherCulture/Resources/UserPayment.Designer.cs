﻿namespace TogetherCulture.Resources
{
    partial class UserPayment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserPayment));
            label1 = new Label();
            label2 = new Label();
            rbMCard = new RadioButton();
            pictureBox2 = new PictureBox();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            tbCardName = new TextBox();
            tbCardNo = new TextBox();
            DTCard = new DateTimePicker();
            tbCVV = new TextBox();
            button1 = new Button();
            rBVisa = new RadioButton();
            pictureBox1 = new PictureBox();
            groupBox1 = new GroupBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(39, 33);
            label1.Name = "label1";
            label1.Size = new Size(120, 32);
            label1.TabIndex = 0;
            label1.Text = "Checkout";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(41, 87);
            label2.Name = "label2";
            label2.Size = new Size(148, 25);
            label2.TabIndex = 1;
            label2.Text = "Payment Method";
            // 
            // rbMCard
            // 
            rbMCard.AutoSize = true;
            rbMCard.Location = new Point(162, 42);
            rbMCard.Name = "rbMCard";
            rbMCard.Size = new Size(21, 20);
            rbMCard.TabIndex = 3;
            rbMCard.TabStop = true;
            rbMCard.UseVisualStyleBackColor = true;
            rbMCard.CheckedChanged += rbMCard_CheckedChanged;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(189, 30);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(74, 49);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 6;
            pictureBox2.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(48, 223);
            label3.Name = "label3";
            label3.Size = new Size(149, 25);
            label3.TabIndex = 8;
            label3.Text = "Cardholder name";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(48, 303);
            label4.Name = "label4";
            label4.Size = new Size(116, 25);
            label4.TabIndex = 9;
            label4.Text = "Card number";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(448, 223);
            label5.Name = "label5";
            label5.Size = new Size(130, 25);
            label5.TabIndex = 10;
            label5.Text = "Expiration date";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(448, 303);
            label6.Name = "label6";
            label6.Size = new Size(45, 25);
            label6.TabIndex = 11;
            label6.Text = "CVV";
            // 
            // tbCardName
            // 
            tbCardName.Location = new Point(48, 251);
            tbCardName.Name = "tbCardName";
            tbCardName.Size = new Size(263, 31);
            tbCardName.TabIndex = 13;
            // 
            // tbCardNo
            // 
            tbCardNo.Location = new Point(48, 340);
            tbCardNo.Name = "tbCardNo";
            tbCardNo.PlaceholderText = "xxxx-xxxx-xxxx-xxxx";
            tbCardNo.Size = new Size(263, 31);
            tbCardNo.TabIndex = 14;
            // 
            // DTCard
            // 
            DTCard.CustomFormat = "MM-yy";
            DTCard.Format = DateTimePickerFormat.Custom;
            DTCard.Location = new Point(448, 258);
            DTCard.MaxDate = new DateTime(2030, 1, 2, 0, 0, 0, 0);
            DTCard.MinDate = new DateTime(2024, 12, 2, 0, 0, 0, 0);
            DTCard.Name = "DTCard";
            DTCard.Size = new Size(118, 31);
            DTCard.TabIndex = 15;
            DTCard.Value = new DateTime(2024, 12, 2, 0, 0, 0, 0);
            // 
            // tbCVV
            // 
            tbCVV.Location = new Point(448, 340);
            tbCVV.Name = "tbCVV";
            tbCVV.PlaceholderText = "123";
            tbCVV.Size = new Size(85, 31);
            tbCVV.TabIndex = 16;
            // 
            // button1
            // 
            button1.Location = new Point(635, 377);
            button1.Name = "button1";
            button1.Size = new Size(112, 34);
            button1.TabIndex = 17;
            button1.Text = "Checkout";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // rBVisa
            // 
            rBVisa.AutoSize = true;
            rBVisa.Location = new Point(17, 42);
            rBVisa.Name = "rBVisa";
            rBVisa.Size = new Size(21, 20);
            rBVisa.TabIndex = 2;
            rBVisa.TabStop = true;
            rBVisa.UseVisualStyleBackColor = true;
            rBVisa.CheckedChanged += rBVisa_CheckedChanged;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.VisaCardjpg;
            pictureBox1.InitialImage = Properties.Resources.VisaCardjpg;
            pictureBox1.Location = new Point(44, 30);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(79, 49);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(rBVisa);
            groupBox1.Controls.Add(rbMCard);
            groupBox1.Controls.Add(pictureBox1);
            groupBox1.Controls.Add(pictureBox2);
            groupBox1.Location = new Point(46, 115);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(300, 91);
            groupBox1.TabIndex = 19;
            groupBox1.TabStop = false;
            // 
            // UserPayment
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(groupBox1);
            Controls.Add(button1);
            Controls.Add(tbCVV);
            Controls.Add(DTCard);
            Controls.Add(tbCardNo);
            Controls.Add(tbCardName);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "UserPayment";
            Text = "Signup";
            Load += UserPayment_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private RadioButton rbMCard;
        private PictureBox pictureBox2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox tbCardName;
        private TextBox tbCardNo;
        private DateTimePicker DTCard;
        private TextBox tbCVV;
        private Button button1;
        private RadioButton rBVisa;
        private PictureBox pictureBox1;
        private GroupBox groupBox1;
    }
}