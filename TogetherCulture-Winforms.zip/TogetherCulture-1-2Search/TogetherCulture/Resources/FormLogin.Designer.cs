﻿namespace TogetherCulture.Resources
{
    partial class FormLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lbUsername = new Label();
            lbPassword = new Label();
            tbUsername = new TextBox();
            tbPassword = new TextBox();
            btLogin = new Button();
            btSignup = new Button();
            label1 = new Label();
            btClose = new Button();
            SuspendLayout();
            // 
            // lbUsername
            // 
            lbUsername.AutoSize = true;
            lbUsername.Location = new Point(79, 139);
            lbUsername.Name = "lbUsername";
            lbUsername.Size = new Size(91, 25);
            lbUsername.TabIndex = 0;
            lbUsername.Text = "Username";
            // 
            // lbPassword
            // 
            lbPassword.AutoSize = true;
            lbPassword.Location = new Point(79, 198);
            lbPassword.Name = "lbPassword";
            lbPassword.Size = new Size(87, 25);
            lbPassword.TabIndex = 1;
            lbPassword.Text = "Password";
            // 
            // tbUsername
            // 
            tbUsername.Location = new Point(200, 139);
            tbUsername.Name = "tbUsername";
            tbUsername.Size = new Size(150, 31);
            tbUsername.TabIndex = 3;
            tbUsername.TextChanged += tbUsername_TextChanged;
            // 
            // tbPassword
            // 
            tbPassword.Location = new Point(200, 198);
            tbPassword.Name = "tbPassword";
            tbPassword.Size = new Size(150, 31);
            tbPassword.TabIndex = 4;
            tbPassword.UseSystemPasswordChar = true;
            // 
            // btLogin
            // 
            btLogin.Location = new Point(134, 289);
            btLogin.Name = "btLogin";
            btLogin.Size = new Size(112, 34);
            btLogin.TabIndex = 6;
            btLogin.Text = "Login";
            btLogin.UseVisualStyleBackColor = true;
            btLogin.Click += btLogin_Click;
            // 
            // btSignup
            // 
            btSignup.Location = new Point(577, 244);
            btSignup.Name = "btSignup";
            btSignup.Size = new Size(112, 34);
            btSignup.TabIndex = 7;
            btSignup.Text = "Signup";
            btSignup.UseVisualStyleBackColor = true;
            btSignup.Click += btSignup_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(511, 179);
            label1.Name = "label1";
            label1.Size = new Size(235, 25);
            label1.TabIndex = 8;
            label1.Text = "Not a Member, Signup Now";
            label1.Click += label1_Click;
            // 
            // btClose
            // 
            btClose.ForeColor = Color.Red;
            btClose.Location = new Point(700, 41);
            btClose.Name = "btClose";
            btClose.Size = new Size(88, 44);
            btClose.TabIndex = 9;
            btClose.Text = "x";
            btClose.UseVisualStyleBackColor = true;
            btClose.Click += btClose_Click;
            // 
            // FormLogin
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btClose);
            Controls.Add(label1);
            Controls.Add(btSignup);
            Controls.Add(btLogin);
            Controls.Add(tbPassword);
            Controls.Add(tbUsername);
            Controls.Add(lbPassword);
            Controls.Add(lbUsername);
            Name = "FormLogin";
            Text = "FormLogin";
            Load += FormLogin_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbUsername;
        private Label lbPassword;
        private TextBox tbUsername;
        private TextBox tbPassword;
        private Button btLogin;
        private Button btSignup;
        private Label label1;
        private GroupBox groupBox1;
        private RadioButton rBVisa;
        private RadioButton rbMCard;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private Button btClose;
    }
}