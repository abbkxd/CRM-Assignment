﻿namespace TogetherCulture.Resources
{
    partial class Userinfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            lbFirstname = new Label();
            lbDOB = new Label();
            lbAddress = new Label();
            tbFname = new TextBox();
            tbLname = new TextBox();
            dTDOB = new DateTimePicker();
            tbAddressBuildNo = new TextBox();
            tbAddresscity = new TextBox();
            tbAddressSN = new TextBox();
            tbAddressPC = new TextBox();
            lbPhno = new Label();
            tbPhno = new TextBox();
            btSubmit = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(12, 19);
            label1.Name = "label1";
            label1.Size = new Size(244, 28);
            label1.TabIndex = 0;
            label1.Text = "Enter your personal details";
            label1.UseWaitCursor = true;
            label1.Click += label1_Click;
            // 
            // lbFirstname
            // 
            lbFirstname.AutoSize = true;
            lbFirstname.Location = new Point(23, 77);
            lbFirstname.Name = "lbFirstname";
            lbFirstname.Size = new Size(59, 25);
            lbFirstname.TabIndex = 1;
            lbFirstname.Text = "Name";
            lbFirstname.Click += label2_Click;
            // 
            // lbDOB
            // 
            lbDOB.AutoSize = true;
            lbDOB.Location = new Point(23, 137);
            lbDOB.Name = "lbDOB";
            lbDOB.Size = new Size(112, 25);
            lbDOB.TabIndex = 3;
            lbDOB.Text = "Date of Birth";
            lbDOB.Click += label4_Click;
            // 
            // lbAddress
            // 
            lbAddress.AutoSize = true;
            lbAddress.Location = new Point(23, 275);
            lbAddress.Name = "lbAddress";
            lbAddress.Size = new Size(77, 25);
            lbAddress.TabIndex = 4;
            lbAddress.Text = "Address";
            // 
            // tbFname
            // 
            tbFname.Location = new Point(187, 77);
            tbFname.Name = "tbFname";
            tbFname.PlaceholderText = "First Name";
            tbFname.Size = new Size(150, 31);
            tbFname.TabIndex = 5;
            // 
            // tbLname
            // 
            tbLname.Location = new Point(361, 77);
            tbLname.Name = "tbLname";
            tbLname.PlaceholderText = "Last Name";
            tbLname.Size = new Size(150, 31);
            tbLname.TabIndex = 6;
            tbLname.TextChanged += tbLname_TextChanged;
            // 
            // dTDOB
            // 
            dTDOB.AllowDrop = true;
            dTDOB.CustomFormat = "";
            dTDOB.Format = DateTimePickerFormat.Short;
            dTDOB.Location = new Point(187, 137);
            dTDOB.MaxDate = new DateTime(2006, 1, 1, 0, 0, 0, 0);
            dTDOB.MinDate = new DateTime(1980, 1, 1, 0, 0, 0, 0);
            dTDOB.Name = "dTDOB";
            dTDOB.Size = new Size(300, 31);
            dTDOB.TabIndex = 7;
            dTDOB.Value = new DateTime(2006, 1, 1, 0, 0, 0, 0);
            dTDOB.ValueChanged += dTDOB_ValueChanged;
            // 
            // tbAddressBuildNo
            // 
            tbAddressBuildNo.Location = new Point(187, 312);
            tbAddressBuildNo.Name = "tbAddressBuildNo";
            tbAddressBuildNo.PlaceholderText = "Building No.";
            tbAddressBuildNo.Size = new Size(150, 31);
            tbAddressBuildNo.TabIndex = 8;
            tbAddressBuildNo.TextChanged += tbAddressBuildNo_TextChanged;
            // 
            // tbAddresscity
            // 
            tbAddresscity.Location = new Point(187, 359);
            tbAddresscity.Name = "tbAddresscity";
            tbAddresscity.PlaceholderText = "City";
            tbAddresscity.Size = new Size(150, 31);
            tbAddresscity.TabIndex = 9;
            // 
            // tbAddressSN
            // 
            tbAddressSN.Location = new Point(361, 312);
            tbAddressSN.Name = "tbAddressSN";
            tbAddressSN.PlaceholderText = "Street Name";
            tbAddressSN.Size = new Size(150, 31);
            tbAddressSN.TabIndex = 10;
            // 
            // tbAddressPC
            // 
            tbAddressPC.Location = new Point(361, 359);
            tbAddressPC.Name = "tbAddressPC";
            tbAddressPC.PlaceholderText = "Post Code";
            tbAddressPC.Size = new Size(150, 31);
            tbAddressPC.TabIndex = 11;
            // 
            // lbPhno
            // 
            lbPhno.AutoSize = true;
            lbPhno.Location = new Point(23, 215);
            lbPhno.Name = "lbPhno";
            lbPhno.Size = new Size(95, 25);
            lbPhno.TabIndex = 12;
            lbPhno.Text = "Phone No.";
            // 
            // tbPhno
            // 
            tbPhno.Location = new Point(187, 215);
            tbPhno.Name = "tbPhno";
            tbPhno.Size = new Size(150, 31);
            tbPhno.TabIndex = 13;
            tbPhno.TextChanged += tbPhno_TextChanged;
            // 
            // btSubmit
            // 
            btSubmit.Location = new Point(659, 382);
            btSubmit.Name = "btSubmit";
            btSubmit.Size = new Size(112, 34);
            btSubmit.TabIndex = 14;
            btSubmit.Text = "Submit";
            btSubmit.UseVisualStyleBackColor = true;
            btSubmit.Click += btSubmit_Click;
            // 
            // Userinfo
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btSubmit);
            Controls.Add(tbPhno);
            Controls.Add(lbPhno);
            Controls.Add(tbAddressPC);
            Controls.Add(tbAddressSN);
            Controls.Add(tbAddresscity);
            Controls.Add(tbAddressBuildNo);
            Controls.Add(dTDOB);
            Controls.Add(tbLname);
            Controls.Add(tbFname);
            Controls.Add(lbAddress);
            Controls.Add(lbDOB);
            Controls.Add(lbFirstname);
            Controls.Add(label1);
            Name = "Userinfo";
            Text = "Signup";
            Load += Signup_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label lbFirstname;
        private Label lbLastname;
        private Label lbDOB;
        private Label lbAddress;
        private TextBox tbFname;
        private TextBox tbLname;
        private DateTimePicker dTDOB;
        private TextBox tbAddressBuildNo;
        private TextBox tbAddresscity;
        private TextBox tbAddressSN;
        private TextBox tbAddressPC;
        private Label lbPhno;
        private TextBox tbPhno;
        private Button btSubmit;
    }
}