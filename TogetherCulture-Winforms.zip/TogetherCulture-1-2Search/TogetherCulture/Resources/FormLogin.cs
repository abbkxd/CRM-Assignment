﻿using System;
using MySql.Data; // MySQL

using System.Security.Cryptography; // For hashing
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace TogetherCulture.Resources
{
    public partial class FormLogin : Form
    {
        private readonly string _connectionString = "Server=localhost;Database=usercred;User Id=root;";
        public FormLogin()
        {
            InitializeComponent();
        }

        private void FormLogin_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }


        // Hashing function
        private static string ComputeSha256Hash(string rawData)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(rawData));
                StringBuilder builder = new StringBuilder();
                foreach (byte b in bytes)
                {
                    builder.Append(b.ToString("x2"));
                }
                return builder.ToString();
            }
        }

        private void btLogin_Click(object sender, EventArgs e)
        {
            string username = tbUsername.Text.Trim();
            string inputPassword = tbPassword.Text.Trim();

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(inputPassword))
            {
                MessageBox.Show("Please fill in both username and password fields.");
                return; 
            }

            // Hash the provided password
            string passwordHash = ComputeSha256Hash(inputPassword);

            try
            {
                using (MySqlConnection connection = new MySqlConnection(_connectionString))
                {
                    string query = "SELECT PasswordHash FROM Users WHERE Username = @username";

                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@username", username);

                        connection.Open();
                        object result = command.ExecuteScalar();

                        if (result != null)
                        {
                            string storedPasswordHash = result.ToString();

                            if (storedPasswordHash == passwordHash) // Compare hashes
                            {
                                MessageBox.Show("Login successful!");


                                Form1 form1 = new Form1(username);
                                this.Hide();
                                form1.Show();


                            }
                            else
                            {
                                MessageBox.Show("Invalid password.");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Invalid username or password.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void btSignup_Click(object sender, EventArgs e)
        {
            FormSignup btSignup = new FormSignup();
            this.Hide();
            btSignup.Show();
        }

        private void tbUsername_TextChanged(object sender, EventArgs e)
        {

        }

        private void btClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }



}
