﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace TogetherCulture.Resources
{
    public partial class UserSub : Form
    {
        private string _usernamefk;

        public UserSub(string username)
        {
            InitializeComponent();
            _usernamefk = username;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void btSubKAM_Click(object sender, EventArgs e)
        {
            String storedSubValue = "Key Access Member";
            this.Hide();
            UserPayment userPayment = new UserPayment(_usernamefk, storedSubValue);
            userPayment.Show();

        }

        private void btSubCM_Click(object sender, EventArgs e)
        {
            String storedSubValue = "Community Member";
            this.Hide();
            UserPayment userPayment = new UserPayment(_usernamefk, storedSubValue);
            userPayment.Show();
        }

        private void btSubSWM_Click(object sender, EventArgs e)
        {
            String storedSubValue = "Creative Workspace Member";
            this.Hide();
            UserPayment userPayment = new UserPayment(_usernamefk, storedSubValue);
            userPayment.Show();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void UserSub_Load(object sender, EventArgs e)
        {

        }
    }
}
