﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TogetherCulture.Resources.UserControlUtils.DashboardSub;

namespace TogetherCulture.Resources.UserControlUtils
{
    public partial class UserControlDashBoard : UserControl
    {
        public UserControlDashBoard()
        {
            InitializeComponent();
        }

        private void notification_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {



        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            pnl_Dasboard.Controls.Clear();


            Total_members totalMembersControl = new Total_members();


            pnl_Dasboard.Controls.Add(totalMembersControl);


            totalMembersControl.Dock = DockStyle.Fill;
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            pnl_Dasboard.Controls.Clear();


            upcomming_events upcommingevents = new upcomming_events();


            pnl_Dasboard.Controls.Add(upcommingevents);


            upcommingevents.Dock = DockStyle.Fill;
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void userinteraction_Click(object sender, EventArgs e)
        {
            pnl_Dasboard.Controls.Clear();


            Userinteraction userinteraction = new Userinteraction();


            pnl_Dasboard.Controls.Add(userinteraction);


            userinteraction.Dock = DockStyle.Fill;
        }
    }
}
