﻿namespace TogetherCulture.Resources.UserControlUtils.EventsSub
{
    partial class UCAddEvents
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCAddEvents));
            pictureBox1 = new PictureBox();
            label2 = new Label();
            tbAddEvent = new TextBox();
            lbEventName = new Label();
            label3 = new Label();
            label4 = new Label();
            DTPEventdate = new DateTimePicker();
            label1 = new Label();
            btAddEvent = new Button();
            CBhour = new ComboBox();
            CBMinute = new ComboBox();
            CBTime = new ComboBox();
            CBHostName = new ComboBox();
            btAddhost = new Button();
            pnaddhost = new Panel();
            label5 = new Label();
            tbEventDescrp = new TextBox();
            pictureBox2 = new PictureBox();
            tbTicketPrice = new TextBox();
            label6 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.add_event;
            pictureBox1.Location = new Point(225, 14);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(200, 82);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 16F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(95, 47);
            label2.Name = "label2";
            label2.Size = new Size(191, 37);
            label2.TabIndex = 3;
            label2.Text = "Add Events";
            // 
            // tbAddEvent
            // 
            tbAddEvent.Location = new Point(376, 167);
            tbAddEvent.Name = "tbAddEvent";
            tbAddEvent.Size = new Size(352, 31);
            tbAddEvent.TabIndex = 4;
            // 
            // lbEventName
            // 
            lbEventName.AutoSize = true;
            lbEventName.Location = new Point(137, 171);
            lbEventName.Name = "lbEventName";
            lbEventName.Size = new Size(107, 25);
            lbEventName.TabIndex = 6;
            lbEventName.Text = "Event Name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(155, 602);
            label3.Name = "label3";
            label3.Size = new Size(132, 25);
            label3.TabIndex = 7;
            label3.Text = "Host Organiser";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(137, 242);
            label4.Name = "label4";
            label4.Size = new Size(49, 25);
            label4.TabIndex = 8;
            label4.Text = "Date";
            // 
            // DTPEventdate
            // 
            DTPEventdate.CustomFormat = "dd-MMMM-yyy";
            DTPEventdate.Format = DateTimePickerFormat.Custom;
            DTPEventdate.Location = new Point(376, 242);
            DTPEventdate.MinDate = new DateTime(2024, 12, 6, 0, 0, 0, 0);
            DTPEventdate.Name = "DTPEventdate";
            DTPEventdate.Size = new Size(300, 31);
            DTPEventdate.TabIndex = 9;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(137, 327);
            label1.Name = "label1";
            label1.Size = new Size(50, 25);
            label1.TabIndex = 10;
            label1.Text = "Time";
            // 
            // btAddEvent
            // 
            btAddEvent.Location = new Point(376, 819);
            btAddEvent.Name = "btAddEvent";
            btAddEvent.Size = new Size(112, 34);
            btAddEvent.TabIndex = 12;
            btAddEvent.Text = "Submit";
            btAddEvent.UseVisualStyleBackColor = true;
            btAddEvent.Click += btAddEvent_Click;
            // 
            // CBhour
            // 
            CBhour.FormattingEnabled = true;
            CBhour.Items.AddRange(new object[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" });
            CBhour.Location = new Point(376, 327);
            CBhour.Name = "CBhour";
            CBhour.Size = new Size(69, 33);
            CBhour.TabIndex = 13;
            // 
            // CBMinute
            // 
            CBMinute.FormattingEnabled = true;
            CBMinute.Items.AddRange(new object[] { "00", "15", "30", "45" });
            CBMinute.Location = new Point(451, 327);
            CBMinute.Name = "CBMinute";
            CBMinute.Size = new Size(69, 33);
            CBMinute.TabIndex = 14;
            // 
            // CBTime
            // 
            CBTime.FormattingEnabled = true;
            CBTime.Items.AddRange(new object[] { "AM", "PM" });
            CBTime.Location = new Point(526, 327);
            CBTime.Name = "CBTime";
            CBTime.Size = new Size(69, 33);
            CBTime.TabIndex = 15;
            // 
            // CBHostName
            // 
            CBHostName.FormattingEnabled = true;
            CBHostName.Items.AddRange(new object[] { "ARU", "TogetherCulture" });
            CBHostName.Location = new Point(376, 602);
            CBHostName.Name = "CBHostName";
            CBHostName.Size = new Size(182, 33);
            CBHostName.TabIndex = 16;
            // 
            // btAddhost
            // 
            btAddhost.Location = new Point(446, 654);
            btAddhost.Name = "btAddhost";
            btAddhost.Size = new Size(112, 34);
            btAddhost.TabIndex = 17;
            btAddhost.Text = "New Host";
            btAddhost.UseVisualStyleBackColor = true;
            btAddhost.Click += btAddhost_Click;
            // 
            // pnaddhost
            // 
            pnaddhost.Location = new Point(578, 602);
            pnaddhost.Name = "pnaddhost";
            pnaddhost.Size = new Size(328, 175);
            pnaddhost.TabIndex = 18;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(137, 440);
            label5.Name = "label5";
            label5.Size = new Size(150, 25);
            label5.TabIndex = 19;
            label5.Text = "Event Description";
            // 
            // tbEventDescrp
            // 
            tbEventDescrp.Location = new Point(376, 437);
            tbEventDescrp.Multiline = true;
            tbEventDescrp.Name = "tbEventDescrp";
            tbEventDescrp.Size = new Size(340, 144);
            tbEventDescrp.TabIndex = 20;
            tbEventDescrp.TextChanged += textBox1_TextChanged;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(925, 219);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(619, 398);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 21;
            pictureBox2.TabStop = false;
            // 
            // tbTicketPrice
            // 
            tbTicketPrice.Location = new Point(376, 391);
            tbTicketPrice.Name = "tbTicketPrice";
            tbTicketPrice.Size = new Size(150, 31);
            tbTicketPrice.TabIndex = 22;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(136, 391);
            label6.Name = "label6";
            label6.Size = new Size(99, 25);
            label6.TabIndex = 23;
            label6.Text = "Ticket Price";
            // 
            // UCAddEvents
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(label6);
            Controls.Add(tbTicketPrice);
            Controls.Add(pictureBox2);
            Controls.Add(tbEventDescrp);
            Controls.Add(label5);
            Controls.Add(pnaddhost);
            Controls.Add(btAddhost);
            Controls.Add(CBHostName);
            Controls.Add(CBTime);
            Controls.Add(CBMinute);
            Controls.Add(CBhour);
            Controls.Add(btAddEvent);
            Controls.Add(label1);
            Controls.Add(DTPEventdate);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(lbEventName);
            Controls.Add(tbAddEvent);
            Controls.Add(label2);
            Controls.Add(pictureBox1);
            Name = "UCAddEvents";
            Size = new Size(1612, 914);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Label label2;
        private TextBox tbAddEvent;
        private Label lbEventName;
        private Label label3;
        private Label label4;
        private DateTimePicker DTPEventdate;
        private Label label1;
        private Button btAddEvent;
        private ComboBox CBhour;
        private ComboBox CBMinute;
        private ComboBox CBTime;
        public ComboBox CBHostName;
        private Button btAddhost;
        public Panel pnaddhost;
        private Label label5;
        private TextBox tbEventDescrp;
        private PictureBox pictureBox2;
        private TextBox tbTicketPrice;
        private Label label6;
    }
}
