﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace TogetherCulture.Resources.UserControlUtils.EventsSub
{
    public partial class addhostname : UserControl
    {
        public event EventHandler<string> DataAdded;

        public addhostname()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            string enteredText = tbaddhost.Text.Trim();

            if (!string.IsNullOrEmpty(enteredText))
            {
                
                DataAdded?.Invoke(this, enteredText);
                tbaddhost.Clear();
            }
            else
            {
                MessageBox.Show("Please enter a valid hostname.");
            }
        }
    }
}
