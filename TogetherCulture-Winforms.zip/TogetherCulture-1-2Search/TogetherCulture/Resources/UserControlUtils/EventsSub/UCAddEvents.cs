﻿using Microsoft.VisualBasic;
using MySql.Data.MySqlClient;
using System;
using System.Diagnostics;
using System.Windows.Forms;

namespace TogetherCulture.Resources.UserControlUtils.EventsSub
{
    public partial class UCAddEvents : UserControl
    {
        private readonly string _connectionString = "Server=localhost;Database=usercred;User Id=root;";

        public UCAddEvents()
        {
            InitializeComponent();
            LoadHostNames();
        }
        private void LoadHostNames()
        {
            try
            {
                using (MySqlConnection connection = new MySqlConnection(_connectionString))
                {
                    connection.Open();
                    string query = "SELECT DISTINCT HostName FROM events" ;

                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        CBHostName.Items.Clear(); 

                        while (reader.Read())
                        {
                            CBHostName.Items.Add(reader.GetString("HostName"));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while loading host names: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btAddhost_Click(object sender, EventArgs e)
        {
            pnaddhost.Controls.Clear();

            addhostname Addhostname = new addhostname();
            pnaddhost.Controls.Add(Addhostname);
            Addhostname.Dock = DockStyle.Fill;

            Addhostname.DataAdded += Addhostname_DataAdded;
        }

        private void Addhostname_DataAdded(object sender, string data)
        {
            CBHostName.Items.Add(data);
            CBHostName.SelectedItem = data;

            if (sender is addhostname addedControl)
            {
                pnaddhost.Controls.Remove(addedControl);
            }
        }

        private void btAddEvent_Click(object sender, EventArgs e)

        {
            ConvertToTime(out DateTime EventTime);

            string Eventname = tbAddEvent.Text;
            DateTime Eventdate = DTPEventdate.Value;
            string Hostname = CBHostName.Text;
            string EventID = EntityID.GenerateId("Event");
            string EventDescrp = tbEventDescrp.Text;
            int TPrice;

            if (int.TryParse(tbTicketPrice.Text, out TPrice))
            { }
            else
            { 
                MessageBox.Show("Please enter a valid integer for the ticket price.");
            }


            if (string.IsNullOrWhiteSpace(Eventname) || string.IsNullOrWhiteSpace(Hostname) || string.IsNullOrWhiteSpace(EventID) || string.IsNullOrWhiteSpace(EventDescrp))
            {
                MessageBox.Show("Please fill in all fields.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string query = @"INSERT INTO events (EventID, EventName, EventDescp, EventDate, EventTime, HostName, TicketPrice) 
                             VALUES (@EventID, @EventName, @EventDescp, @EventDate, @EventTime, @HostName, @TPrice)";

            try
            {
                using (MySqlConnection connection = new MySqlConnection(_connectionString))
                {
                    connection.Open();
                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@EventID", EventID);
                        command.Parameters.AddWithValue("@EventName", Eventname);
                        command.Parameters.AddWithValue("@EventDescp", EventDescrp);
                        command.Parameters.AddWithValue("@EventDate", Eventdate);
                        command.Parameters.AddWithValue("@EventTime", EventTime);
                        command.Parameters.AddWithValue("@HostName", Hostname);
                        command.Parameters.AddWithValue("@TPrice", TPrice);

                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Event added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            tbAddEvent.Clear();
                            tbEventDescrp.Clear();
                            CBHostName.SelectedIndex = -1; 
                            DTPEventdate.Value = DateTime.Now;
                        }
                        else
                        {
                            MessageBox.Show("Failed to add event.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        private void ConvertToTime(out DateTime EventTime)
        {
            try
            {
                int hours = int.Parse(CBhour.SelectedItem.ToString());
                int minutes = int.Parse(CBMinute.SelectedItem.ToString());
                string ampm = CBTime.SelectedItem.ToString();

                if (ampm == "PM" && hours != 12)
                {
                    hours += 12;
                }
                else if (ampm == "AM" && hours == 12)
                {
                    hours = 0;
                }
                EventTime = new DateTime(1, 1, 1, hours, minutes, 0); // Dummy year, month, day
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                EventTime = DateTime.MinValue; 
            }
        }



        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }
    }
}
 