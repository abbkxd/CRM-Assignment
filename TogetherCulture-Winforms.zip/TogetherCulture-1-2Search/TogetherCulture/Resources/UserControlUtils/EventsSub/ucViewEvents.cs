﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace TogetherCulture.Resources.UserControlUtils.EventsSub
{
    public partial class ucViewEvents : UserControl
    {
        private readonly string _connectionString = "Server=localhost;Database=usercred;User Id=root;";
        private List<EventData> _events;
        private DateTime _currentWeekStart;
        private DateTime _currentWeekEnd;

        public ucViewEvents()
        {
            InitializeComponent();
            _currentWeekStart = StartOfWeek(DateTime.Now);
            _currentWeekEnd = _currentWeekStart.AddDays(6);
            _events = new List<EventData>();


            pnChart.Paint += pnChart_Paint;
            LoadEvents();
        }

        private void LoadEvents()
        {
            try
            {
                using (MySqlConnection connection = new MySqlConnection(_connectionString))
                {
                    string query = "SELECT EventID, EventName, EventDate, EventTime, HostName, EventDescp FROM events";
                    MySqlCommand command = new MySqlCommand(query, connection);
                    connection.Open();
                    MySqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        DateTime eventDate = reader.GetDateTime("EventDate");
                        TimeSpan eventTime = reader.GetTimeSpan("EventTime");
                        DateTime startDateTime = eventDate.Date + eventTime;

                        
                        if (startDateTime >= _currentWeekStart && startDateTime <= _currentWeekEnd)
                        {
                            _events.Add(new EventData
                            {
                                EventName = reader.GetString("EventName"),
                                StartDateTime = startDateTime,
                                Duration = TimeSpan.FromHours(1) 
                            });
                        }
                    }
                }
                pnChart.Invalidate(); 
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while loading events: " + ex.Message);
            }
        }

        private void pnChart_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            int startX = 50;
            int startY = 20;
            int dayWidth = 80; 
            int hourHeight = 30; 
            int eventHeight = 20; 
            int daysInWeek = 7;

            
            Font font = new Font("Arial", 8);
            for (int day = 0; day < daysInWeek; day++)
            {
                DateTime currentDay = _currentWeekStart.AddDays(day);
                string dayLabel = currentDay.ToString("ddd, d");
                g.DrawString(dayLabel, font, Brushes.Black, startX + day * dayWidth, 10);
                g.DrawLine(Pens.Black, startX + day * dayWidth, 40, startX + day * dayWidth, pnChart.Height - 30);
            }

            
            Font eventFont = new Font("Arial", 10);
            foreach (EventData eventData in _events)
            {
                int dayOffset = (eventData.StartDateTime.DayOfWeek - _currentWeekStart.DayOfWeek) * dayWidth;
                int eventStartX = startX + dayOffset + (eventData.StartDateTime.Hour * dayWidth / 24);
                int eventStartY = startY + (eventData.StartDateTime.Hour * hourHeight / 24);

                
                g.FillRectangle(Brushes.LightBlue, eventStartX, eventStartY, dayWidth, eventHeight);
                g.DrawRectangle(Pens.Blue, eventStartX, eventStartY, dayWidth, eventHeight);

               
                g.DrawString(eventData.EventName, eventFont, Brushes.Black, eventStartX + 5, eventStartY + 5);
            }

            font.Dispose();
            eventFont.Dispose();
        }

        private DateTime StartOfWeek(DateTime date)
        {
            DayOfWeek day = date.DayOfWeek;
            int diff = day - DayOfWeek.Monday;
            if (diff < 0) diff += 7;
            return date.AddDays(-diff).Date;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }

    public class EventData
    {
        public string EventName { get; set; }
        public DateTime StartDateTime { get; set; }
        public TimeSpan Duration { get; set; }
    }
}
