﻿using System;
using System.Windows.Forms;  
namespace TogetherCulture.Resources.UserControlUtils.EventsSub
{
    internal class MessageboxmissingError
    {
        public void ShowErrorMessage()
        {

            MessageBox.Show("Enter missing data.");
        }
    }
}
