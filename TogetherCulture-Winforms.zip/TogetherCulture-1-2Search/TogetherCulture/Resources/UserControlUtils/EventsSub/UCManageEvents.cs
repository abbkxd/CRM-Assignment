﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TogetherCulture.Resources.UserControlUtils.EventsSub
{
    public partial class UCManageEvents : UserControl
    {
        public UCManageEvents()
        {
            InitializeComponent();

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            pnUserControlEvents.Controls.Clear();
            ucDeleteEvent UCDeleteEvent = new ucDeleteEvent();
            pnUserControlEvents.Controls.Add(UCDeleteEvent);
            UCDeleteEvent.Dock = DockStyle.Fill;
        }
        private void ppnDeleteEvent_Click(object sender, EventArgs e)
        {
            pnUserControlEvents.Controls.Clear();
            ucDeleteEvent UCDeleteEvent = new ucDeleteEvent();
            pnUserControlEvents.Controls.Add(UCDeleteEvent);
            UCDeleteEvent.Dock = DockStyle.Fill;
        }



        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void pnUserControlEvents_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            pnUserControlEvents.Controls.Clear();
            ucEditEvents UCEditEvent = new ucEditEvents();
            pnUserControlEvents.Controls.Add(UCEditEvent);
            UCEditEvent.Dock = DockStyle.Fill;
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            pnUserControlEvents.Controls.Clear();
            ucViewEvents UCviewEvent = new ucViewEvents();
            pnUserControlEvents.Controls.Add(UCviewEvent);
            UCviewEvent.Dock = DockStyle.Fill;
        }
    }
}
