﻿namespace TogetherCulture.Resources.UserControlUtils.EventsSub
{
    partial class ucDeleteEvent
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }





        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            eventsDataGridView = new DataGridView();
            deleteButton = new Button();
            ((System.ComponentModel.ISupportInitialize)eventsDataGridView).BeginInit();
            SuspendLayout();
            // 
            // eventsDataGridView
            // 
            eventsDataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            eventsDataGridView.Location = new Point(124, 34);
            eventsDataGridView.Name = "eventsDataGridView";
            eventsDataGridView.RowHeadersWidth = 62;
            eventsDataGridView.Size = new Size(616, 302);
            eventsDataGridView.TabIndex = 0;
            // 
            // deleteButton
            // 
            deleteButton.Location = new Point(976, 163);
            deleteButton.Name = "deleteButton";
            deleteButton.Size = new Size(112, 34);
            deleteButton.TabIndex = 1;
            deleteButton.Text = "Delete";
            deleteButton.UseVisualStyleBackColor = true;
            deleteButton.Click += deleteButton_Click_1;
            // 
            // ucDeleteEvent
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(deleteButton);
            Controls.Add(eventsDataGridView);
            Name = "ucDeleteEvent";
            Size = new Size(1562, 469);
            ((System.ComponentModel.ISupportInitialize)eventsDataGridView).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView eventsDataGridView;
        private Button deleteButton;
    }



}
