﻿namespace TogetherCulture.Resources.UserControlUtils.EventsSub
{
    partial class ucEditEvents
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DGVEventUpdate = new DataGridView();
            tbEventName = new TextBox();
            tbHostName = new TextBox();
            tbEventDescrp = new TextBox();
            DTPEventDate = new DateTimePicker();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            btUpdateEvent = new Button();
            DTPEventTime = new DateTimePicker();
            label5 = new Label();
            label6 = new Label();
            tbTPrice = new TextBox();
            ((System.ComponentModel.ISupportInitialize)DGVEventUpdate).BeginInit();
            SuspendLayout();
            // 
            // DGVEventUpdate
            // 
            DGVEventUpdate.AllowUserToAddRows = false;
            DGVEventUpdate.AllowUserToDeleteRows = false;
            DGVEventUpdate.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DGVEventUpdate.Location = new Point(18, 32);
            DGVEventUpdate.Name = "DGVEventUpdate";
            DGVEventUpdate.RowHeadersWidth = 62;
            DGVEventUpdate.Size = new Size(610, 307);
            DGVEventUpdate.TabIndex = 0;
            // 
            // tbEventName
            // 
            tbEventName.Location = new Point(906, 62);
            tbEventName.Name = "tbEventName";
            tbEventName.Size = new Size(150, 31);
            tbEventName.TabIndex = 1;
            // 
            // tbHostName
            // 
            tbHostName.Location = new Point(906, 221);
            tbHostName.Name = "tbHostName";
            tbHostName.Size = new Size(150, 31);
            tbHostName.TabIndex = 2;
            // 
            // tbEventDescrp
            // 
            tbEventDescrp.Location = new Point(906, 258);
            tbEventDescrp.Multiline = true;
            tbEventDescrp.Name = "tbEventDescrp";
            tbEventDescrp.Size = new Size(339, 186);
            tbEventDescrp.TabIndex = 3;
            // 
            // DTPEventDate
            // 
            DTPEventDate.CustomFormat = "";
            DTPEventDate.Location = new Point(906, 102);
            DTPEventDate.Name = "DTPEventDate";
            DTPEventDate.Size = new Size(300, 31);
            DTPEventDate.TabIndex = 4;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(757, 62);
            label1.Name = "label1";
            label1.Size = new Size(107, 25);
            label1.TabIndex = 5;
            label1.Text = "Event Name";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(766, 221);
            label2.Name = "label2";
            label2.Size = new Size(94, 25);
            label2.TabIndex = 6;
            label2.Text = "Hostname";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(767, 102);
            label3.Name = "label3";
            label3.Size = new Size(97, 25);
            label3.TabIndex = 7;
            label3.Text = "Event Date";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(714, 258);
            label4.Name = "label4";
            label4.Size = new Size(150, 25);
            label4.TabIndex = 8;
            label4.Text = "Event Description";
            // 
            // btUpdateEvent
            // 
            btUpdateEvent.Location = new Point(1372, 410);
            btUpdateEvent.Name = "btUpdateEvent";
            btUpdateEvent.Size = new Size(112, 34);
            btUpdateEvent.TabIndex = 9;
            btUpdateEvent.Text = "Update";
            btUpdateEvent.UseVisualStyleBackColor = true;
            btUpdateEvent.Click += btUpdateEvent_Click;
            // 
            // DTPEventTime
            // 
            DTPEventTime.Format = DateTimePickerFormat.Time;
            DTPEventTime.Location = new Point(906, 139);
            DTPEventTime.Name = "DTPEventTime";
            DTPEventTime.Size = new Size(300, 31);
            DTPEventTime.TabIndex = 10;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(766, 145);
            label5.Name = "label5";
            label5.Size = new Size(98, 25);
            label5.TabIndex = 11;
            label5.Text = "Event Time";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(762, 183);
            label6.Name = "label6";
            label6.Size = new Size(99, 25);
            label6.TabIndex = 12;
            label6.Text = "Ticket Price";
            // 
            // tbTPrice
            // 
            tbTPrice.Location = new Point(906, 180);
            tbTPrice.Name = "tbTPrice";
            tbTPrice.Size = new Size(66, 31);
            tbTPrice.TabIndex = 13;
            // 
            // ucEditEvents
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(tbTPrice);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(DTPEventTime);
            Controls.Add(btUpdateEvent);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(DTPEventDate);
            Controls.Add(tbEventDescrp);
            Controls.Add(tbHostName);
            Controls.Add(tbEventName);
            Controls.Add(DGVEventUpdate);
            Name = "ucEditEvents";
            Size = new Size(1562, 469);
            ((System.ComponentModel.ISupportInitialize)DGVEventUpdate).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView DGVEventUpdate;
        private TextBox tbEventName;
        private TextBox tbHostName;
        private TextBox tbEventDescrp;
        private DateTimePicker DTPEventDate;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Button btUpdateEvent;
        private DateTimePicker DTPEventTime;
        private Label label5;
        private Label label6;
        private TextBox tbTPrice;
    }
}
