﻿namespace TogetherCulture.Resources.UserControlUtils.EventsSub
{
    partial class addhostname
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tbaddhost = new TextBox();
            button1 = new Button();
            SuspendLayout();
            // 
            // tbaddhost
            // 
            tbaddhost.BackColor = SystemColors.InactiveBorder;
            tbaddhost.Location = new Point(3, 3);
            tbaddhost.Name = "tbaddhost";
            tbaddhost.Size = new Size(198, 31);
            tbaddhost.TabIndex = 0;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.InactiveBorder;
            button1.Location = new Point(44, 54);
            button1.Name = "button1";
            button1.Size = new Size(112, 34);
            button1.TabIndex = 1;
            button1.Text = "Add Host";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // addhostname
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(button1);
            Controls.Add(tbaddhost);
            Name = "addhostname";
            Size = new Size(328, 175);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox tbaddhost;
        private Button button1;
    }
}
