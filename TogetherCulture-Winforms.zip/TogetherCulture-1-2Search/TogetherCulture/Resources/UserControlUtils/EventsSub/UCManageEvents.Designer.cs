﻿namespace TogetherCulture.Resources.UserControlUtils.EventsSub
{
    partial class UCManageEvents
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCManageEvents));
            pictureBox2 = new PictureBox();
            label3 = new Label();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            pictureBox3 = new PictureBox();
            pnDeleteEvent = new Panel();
            label4 = new Label();
            pnEditEvents = new Panel();
            pnViewEvents = new Panel();
            label2 = new Label();
            pictureBox4 = new PictureBox();
            pnUserControlEvents = new Panel();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            pnDeleteEvent.SuspendLayout();
            pnEditEvents.SuspendLayout();
            pnViewEvents.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            SuspendLayout();
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.manageevent1;
            pictureBox2.Location = new Point(33, 3);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(311, 193);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 6;
            pictureBox2.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 16F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(285, 78);
            label3.Name = "label3";
            label3.Size = new Size(249, 37);
            label3.TabIndex = 7;
            label3.Text = "Manage Events";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(77, 120);
            label1.Name = "label1";
            label1.Size = new Size(154, 26);
            label1.TabIndex = 8;
            label1.Text = "Delete Events";
            label1.Click += label1_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(45, 15);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(209, 131);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 10;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(48, 15);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(209, 131);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 11;
            pictureBox3.TabStop = false;
            pictureBox3.Click += pictureBox3_Click;
            // 
            // pnDeleteEvent
            // 
            pnDeleteEvent.Controls.Add(label1);
            pnDeleteEvent.Controls.Add(pictureBox1);
            pnDeleteEvent.Location = new Point(39, 255);
            pnDeleteEvent.Name = "pnDeleteEvent";
            pnDeleteEvent.Size = new Size(305, 161);
            pnDeleteEvent.TabIndex = 12;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(82, 120);
            label4.Name = "label4";
            label4.Size = new Size(130, 26);
            label4.TabIndex = 11;
            label4.Text = "Edit Events";
            label4.Click += label4_Click;
            // 
            // pnEditEvents
            // 
            pnEditEvents.Controls.Add(label4);
            pnEditEvents.Controls.Add(pictureBox3);
            pnEditEvents.Location = new Point(475, 255);
            pnEditEvents.Name = "pnEditEvents";
            pnEditEvents.Size = new Size(305, 161);
            pnEditEvents.TabIndex = 13;
            // 
            // pnViewEvents
            // 
            pnViewEvents.Controls.Add(label2);
            pnViewEvents.Controls.Add(pictureBox4);
            pnViewEvents.Location = new Point(914, 255);
            pnViewEvents.Name = "pnViewEvents";
            pnViewEvents.Size = new Size(305, 161);
            pnViewEvents.TabIndex = 14;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(70, 120);
            label2.Name = "label2";
            label2.Size = new Size(141, 26);
            label2.TabIndex = 11;
            label2.Text = "View Events";
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(28, 15);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(209, 131);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 11;
            pictureBox4.TabStop = false;
            pictureBox4.Click += pictureBox4_Click;
            // 
            // pnUserControlEvents
            // 
            pnUserControlEvents.Location = new Point(33, 442);
            pnUserControlEvents.Name = "pnUserControlEvents";
            pnUserControlEvents.Size = new Size(1562, 469);
            pnUserControlEvents.TabIndex = 15;
            pnUserControlEvents.Paint += pnUserControlEvents_Paint;
            // 
            // UCManageEvents
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(pnUserControlEvents);
            Controls.Add(pnViewEvents);
            Controls.Add(pnEditEvents);
            Controls.Add(pnDeleteEvent);
            Controls.Add(label3);
            Controls.Add(pictureBox2);
            Name = "UCManageEvents";
            Size = new Size(1612, 914);
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            pnDeleteEvent.ResumeLayout(false);
            pnDeleteEvent.PerformLayout();
            pnEditEvents.ResumeLayout(false);
            pnEditEvents.PerformLayout();
            pnViewEvents.ResumeLayout(false);
            pnViewEvents.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox2;
        private Label label3;
        private Label label1;
        private PictureBox pictureBox1;
        private PictureBox pictureBox3;
        private Panel pnDeleteEvent;
        private Label label4;
        private Panel pnEditEvents;
        private Panel pnViewEvents;
        private Label label2;
        private PictureBox pictureBox4;
        public Panel pnUserControlEvents;
    }
}
