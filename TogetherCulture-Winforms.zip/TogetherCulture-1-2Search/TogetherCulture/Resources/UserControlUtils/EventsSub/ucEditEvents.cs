﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows.Forms;

namespace TogetherCulture.Resources.UserControlUtils.EventsSub
{
    public partial class ucEditEvents : UserControl
    {
        private readonly string _connectionString = "Server=localhost;Database=usercred;User Id=root;";

        public ucEditEvents()
        {
            InitializeComponent();
            LoadEvents();
            this.DGVEventUpdate.CellClick += new DataGridViewCellEventHandler(this.DGVEventUpdate_CellClick);
            DTPEventTime.Format = DateTimePickerFormat.Custom;
            DTPEventTime.CustomFormat = "HH:mm";
            DTPEventTime.ShowUpDown = true;
        }

        private void LoadEvents()
        {
            try
            {
                using (MySqlConnection connection = new MySqlConnection(_connectionString))
                {
                    string query = "SELECT EventID, EventName, EventDate, EventTime, TicketPrice, HostName, EventDescp FROM events";
                    MySqlDataAdapter dataAdapter = new MySqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    dataAdapter.Fill(dataTable);

                    if (dataTable.Rows.Count > 0)
                    {
                        DGVEventUpdate.DataSource = dataTable;
                        DGVEventUpdate.ReadOnly = true;
                        DGVEventUpdate.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                        DGVEventUpdate.MultiSelect = false;

                        if (DGVEventUpdate.Columns["EventID"] != null)
                        {
                            DGVEventUpdate.Columns["EventID"].Visible = false;
                        }
                    }
                    else
                    {
                        MessageBox.Show("No events found in the database.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while loading events: " + ex.Message);
            }
        }

        private void DGVEventUpdate_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                try
                {
                    DataGridViewRow selectedRow = DGVEventUpdate.Rows[e.RowIndex];

                    tbEventName.Text = selectedRow.Cells["EventName"].Value?.ToString() ?? string.Empty;
                    tbHostName.Text = selectedRow.Cells["HostName"].Value?.ToString() ?? string.Empty;
                    tbEventDescrp.Text = selectedRow.Cells["EventDescp"].Value?.ToString() ?? string.Empty;

                    
                    int ticketPrice;
                    if (int.TryParse(selectedRow.Cells["TicketPrice"].Value?.ToString(), out ticketPrice))
                    {
                        tbTPrice.Text = ticketPrice.ToString();
                    }
                    else
                    {
                        tbTPrice.Text = "0"; 
                    }

                    if (selectedRow.Cells["EventDate"].Value != DBNull.Value && selectedRow.Cells["EventDate"].Value != null)
                    {
                        DateTime eventDate = Convert.ToDateTime(selectedRow.Cells["EventDate"].Value);
                        DTPEventDate.Value = eventDate;
                    }
                    else
                    {
                        DTPEventDate.Value = DateTime.Now;
                    }

                    if (selectedRow.Cells["EventTime"].Value != DBNull.Value && selectedRow.Cells["EventTime"].Value != null)
                    {
                        if (selectedRow.Cells["EventTime"].Value is TimeSpan eventTime)
                        {
                            DateTime tempDateTime = new DateTime(1, 1, 1, eventTime.Hours, eventTime.Minutes, eventTime.Seconds);
                            if (tempDateTime >= DTPEventTime.MinDate && tempDateTime <= DTPEventTime.MaxDate)
                            {
                                DTPEventTime.Value = tempDateTime;
                            }
                            else
                            {
                                DTPEventTime.Value = DateTime.Now;
                            }
                        }
                        else
                        {
                            DTPEventTime.Value = DateTime.Now;
                        }
                    }
                    else
                    {
                        DTPEventTime.Value = DateTime.Now;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred while populating the form: " + ex.Message);
                }
            }
        }

        private void btUpdateEvent_Click(object sender, EventArgs e)
        {
            try
            {
                if (DGVEventUpdate.SelectedRows.Count > 0)
                {
                    DataGridViewRow selectedRow = DGVEventUpdate.SelectedRows[0];
                    string eventId = selectedRow.Cells["EventID"].Value.ToString();
                    string eventName = tbEventName.Text;
                    string hostName = tbHostName.Text;
                    string eventDescp = tbEventDescrp.Text;

                    
                    int TicketPrice;
                    if (!int.TryParse(tbTPrice.Text, out TicketPrice))
                    {
                        MessageBox.Show("Please enter a valid ticket price.");
                        return; 
                    }

                    DateTime eventDate = DTPEventDate.Value;
                    DateTime eventTime = DTPEventTime.Value;

                    DateTime eventDateTime = eventDate.Date + eventTime.TimeOfDay;

                    var result = MessageBox.Show($"Are you sure you want to update the event:\n\n" +
                                                 $"Event Name: {eventName}\nHost Name: {hostName}\nDate/Time: {eventDateTime.ToShortDateString()} {eventDateTime.ToShortTimeString()}\nDescription: {eventDescp}",
                                                 "Confirm Update", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                    if (result == DialogResult.Yes)
                    {
                        using (MySqlConnection connection = new MySqlConnection(_connectionString))
                        {
                            string updateQuery = @"
                            UPDATE events
                            SET EventName = @EventName,
                                EventDate = @EventDate,
                                EventTime = @EventTime,
                                HostName = @HostName,
                                EventDescp = @EventDescp,
                                TicketPrice = @TicketPrice
                            WHERE EventID = @EventID";

                            MySqlCommand command = new MySqlCommand(updateQuery, connection);
                            command.Parameters.AddWithValue("@EventID", eventId);
                            command.Parameters.AddWithValue("@EventName", eventName);
                            command.Parameters.AddWithValue("@EventDate", eventDateTime.Date);
                            command.Parameters.AddWithValue("@EventTime", eventDateTime.TimeOfDay);
                            command.Parameters.AddWithValue("@HostName", hostName);
                            command.Parameters.AddWithValue("@EventDescp", eventDescp);
                            command.Parameters.AddWithValue("@TicketPrice", TicketPrice);

                            connection.Open();
                            int rowsAffected = command.ExecuteNonQuery();
                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Event updated successfully!");
                                LoadEvents();
                            }
                            else
                            {
                                MessageBox.Show("Error: Event could not be updated. Please try again.");
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please select an event to update.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while updating the event: " + ex.Message);
            }
        }
    }
}
