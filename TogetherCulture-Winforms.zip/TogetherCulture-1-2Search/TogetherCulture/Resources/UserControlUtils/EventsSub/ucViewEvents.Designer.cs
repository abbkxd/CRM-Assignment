﻿using System.Security.Cryptography.X509Certificates;

namespace TogetherCulture.Resources.UserControlUtils.EventsSub
{
    partial class ucViewEvents
    {

        private void InitializeComponent()
        {
            pnChart = new Panel();
            label1 = new Label();
            SuspendLayout();
            // 
            // pnChart
            // 
            pnChart.Location = new Point(240, 35);
            pnChart.Name = "pnChart";
            pnChart.Size = new Size(1304, 401);
            pnChart.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(855, 439);
            label1.Name = "label1";
            label1.RightToLeft = RightToLeft.No;
            label1.Size = new Size(132, 29);
            label1.TabIndex = 1;
            label1.Text = "This Week";
            label1.Click += label1_Click;
            // 
            // ucViewEvents
            // 
            Controls.Add(label1);
            Controls.Add(pnChart);
            Name = "ucViewEvents";
            Size = new Size(1562, 469);
            ResumeLayout(false);
            PerformLayout();
        }

        private Panel pnChart;
        private Label label1;
    }
}
