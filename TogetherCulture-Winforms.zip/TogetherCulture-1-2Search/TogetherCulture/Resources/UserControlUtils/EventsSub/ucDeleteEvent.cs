﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows.Forms;

namespace TogetherCulture.Resources.UserControlUtils.EventsSub
{
    public partial class ucDeleteEvent : UserControl
    {
        private readonly string _connectionString = "Server=localhost;Database=usercred;User Id=root;";

        public ucDeleteEvent()
        {
            InitializeComponent();
            LoadEvents();
        }

        private void LoadEvents()
        {
            try
            {
                using (MySqlConnection connection = new MySqlConnection(_connectionString))
                {
                    string query = "SELECT EventID, EventName, EventDate FROM events";
                    MySqlDataAdapter dataAdapter = new MySqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    dataAdapter.Fill(dataTable);

                    eventsDataGridView.DataSource = dataTable;
                    eventsDataGridView.ReadOnly = true;
                    eventsDataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                    eventsDataGridView.MultiSelect = false;

                    if (eventsDataGridView.Columns["EventID"] != null)
                    {
                        eventsDataGridView.Columns["EventID"].Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while loading events: " + ex.Message);
            }
        }

        private void deleteButton_Click_1(object sender, EventArgs e)
        {
            try
            {
                if (eventsDataGridView.SelectedRows.Count > 0)
                {
                    string eventId = ((DataTable)eventsDataGridView.DataSource)
                                     .Rows[eventsDataGridView.SelectedRows[0].Index]["EventID"].ToString();

                    string eventName = eventsDataGridView.SelectedRows[0].Cells["EventName"].Value.ToString();
                    string eventDate = eventsDataGridView.SelectedRows[0].Cells["EventDate"].Value.ToString();

                    var result = MessageBox.Show($"Are you sure you want to delete the event:\n\n" +
                                                 $"Name: {eventName}\nDate: {eventDate}?",
                                                 "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                    if (result == DialogResult.Yes)
                    {
                        using (MySqlConnection connection = new MySqlConnection(_connectionString))
                        {
                            string deleteQuery = "DELETE FROM events WHERE EventID = @EventID";
                            MySqlCommand command = new MySqlCommand(deleteQuery, connection);
                            command.Parameters.AddWithValue("@EventID", eventId);

                            connection.Open();
                            int rowsAffected = command.ExecuteNonQuery();
                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Event deleted successfully!");
                                LoadEvents();
                            }
                            else
                            {
                                MessageBox.Show("Error: Event could not be deleted. Please try again.");
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please select an event to delete.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while deleting the event: " + ex.Message);
            }
        }
    }
}
