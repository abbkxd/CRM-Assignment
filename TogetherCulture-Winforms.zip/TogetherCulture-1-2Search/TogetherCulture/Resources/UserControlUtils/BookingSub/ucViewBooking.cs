﻿using System;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace TogetherCulture.Resources.UserControlUtils.BookingSub
{
    public partial class ucViewBooking : UserControl
    {
        private string connectionString = "Server=localhost;Database=usercred;User Id=root;";

        public ucViewBooking()
        {
            InitializeComponent();
            LoadThisMonthBookings(); // default

            btEventWeek.Click += BtEventWeek_Click;
            btEventMonth.Click += BtEventMonth_Click;
        }

        private void LoadThisMonthBookings()
        {
            string query = @"
                SELECT Booking_ID, Facility_ID, User_ID, Slot_Booked, Slot_Duration, Booking_Status
                FROM booking
                WHERE MONTH(Slot_Booked) = MONTH(CURDATE()) AND YEAR(Slot_Booked) = YEAR(CURDATE())";

            LoadDataIntoGrid(query);
        }

        private void LoadThisWeekBookings()
        {
            string query = @"
                SELECT Booking_ID, Facility_ID, User_ID, Slot_Booked, Slot_Duration, Booking_Status
                FROM booking
                WHERE WEEK(Slot_Booked, 1) = WEEK(CURDATE(), 1) AND YEAR(Slot_Booked) = YEAR(CURDATE())";

            LoadDataIntoGrid(query);
        }

        private void LoadDataIntoGrid(string query)
        {
            try
            {
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    connection.Open();
                    MySqlDataAdapter adapter = new MySqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dataGridView1.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtEventWeek_Click(object sender, EventArgs e)
        {
            LoadThisWeekBookings();
        }

        private void BtEventMonth_Click(object sender, EventArgs e)
        {
            LoadThisMonthBookings();
        }
    }
}
