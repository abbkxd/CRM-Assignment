﻿namespace TogetherCulture.Resources.UserControlUtils.BookingSub
{
    partial class ucViewBooking
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            btEventWeek = new Button();
            btEventMonth = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(130, 56);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(984, 379);
            dataGridView1.TabIndex = 0;
            // 
            // btEventWeek
            // 
            btEventWeek.Location = new Point(1235, 209);
            btEventWeek.Name = "btEventWeek";
            btEventWeek.Size = new Size(178, 34);
            btEventWeek.TabIndex = 1;
            btEventWeek.Text = "Current Week";
            btEventWeek.UseVisualStyleBackColor = true;
            // 
            // btEventMonth
            // 
            btEventMonth.Location = new Point(1235, 279);
            btEventMonth.Name = "btEventMonth";
            btEventMonth.Size = new Size(178, 34);
            btEventMonth.TabIndex = 2;
            btEventMonth.Text = "Current Month";
            btEventMonth.UseVisualStyleBackColor = true;
            // 
            // ucViewBooking
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(btEventMonth);
            Controls.Add(btEventWeek);
            Controls.Add(dataGridView1);
            Name = "ucViewBooking";
            Size = new Size(1579, 438);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dataGridView1;
        private Button btEventWeek;
        private Button btEventMonth;
    }
}
