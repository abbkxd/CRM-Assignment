﻿namespace TogetherCulture.Resources.UserControlUtils.BookingSub
{
    partial class ucManageBooking
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DGVBooking = new DataGridView();
            tbFaciltyID = new TextBox();
            tbUserID = new TextBox();
            mySqlCommand1 = new MySql.Data.MySqlClient.MySqlCommand();
            CBBookingStatus = new ComboBox();
            DTPSlotDate = new DateTimePicker();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            DTPSlotTime = new DateTimePicker();
            btaddB = new Button();
            btEditB = new Button();
            btDBooking = new Button();
            ((System.ComponentModel.ISupportInitialize)DGVBooking).BeginInit();
            SuspendLayout();
            // 
            // DGVBooking
            // 
            DGVBooking.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DGVBooking.Location = new Point(66, 30);
            DGVBooking.Name = "DGVBooking";
            DGVBooking.RowHeadersWidth = 62;
            DGVBooking.Size = new Size(683, 390);
            DGVBooking.TabIndex = 0;
            DGVBooking.CellClick += DGVBooking_CellClick;
            // 
            // tbFaciltyID
            // 
            tbFaciltyID.Location = new Point(1131, 36);
            tbFaciltyID.Name = "tbFaciltyID";
            tbFaciltyID.Size = new Size(150, 31);
            tbFaciltyID.TabIndex = 1;
            // 
            // tbUserID
            // 
            tbUserID.Location = new Point(1131, 102);
            tbUserID.Name = "tbUserID";
            tbUserID.Size = new Size(150, 31);
            tbUserID.TabIndex = 2;
            // 
            // mySqlCommand1
            // 
            mySqlCommand1.CacheAge = 0;
            mySqlCommand1.Connection = null;
            mySqlCommand1.EnableCaching = false;
            mySqlCommand1.Transaction = null;
            // 
            // CBBookingStatus
            // 
            CBBookingStatus.FormattingEnabled = true;
            CBBookingStatus.Items.AddRange(new object[] { "Confirmed", "Pending", "Cancelled" });
            CBBookingStatus.Location = new Point(1131, 274);
            CBBookingStatus.Name = "CBBookingStatus";
            CBBookingStatus.Size = new Size(182, 33);
            CBBookingStatus.TabIndex = 5;
            // 
            // DTPSlotDate
            // 
            DTPSlotDate.Location = new Point(1131, 155);
            DTPSlotDate.Name = "DTPSlotDate";
            DTPSlotDate.Size = new Size(300, 31);
            DTPSlotDate.TabIndex = 6;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(941, 36);
            label1.Name = "label1";
            label1.Size = new Size(82, 25);
            label1.TabIndex = 7;
            label1.Text = "FacilityID";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(958, 102);
            label2.Name = "label2";
            label2.Size = new Size(65, 25);
            label2.TabIndex = 8;
            label2.Text = "UserID";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(938, 155);
            label3.Name = "label3";
            label3.Size = new Size(85, 25);
            label3.TabIndex = 9;
            label3.Text = "Slot Date";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(892, 274);
            label4.Name = "label4";
            label4.Size = new Size(131, 25);
            label4.TabIndex = 10;
            label4.Text = "Booking Status";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(937, 216);
            label5.Name = "label5";
            label5.Size = new Size(86, 25);
            label5.TabIndex = 11;
            label5.Text = "Slot Time";
            // 
            // DTPSlotTime
            // 
            DTPSlotTime.Format = DateTimePickerFormat.Time;
            DTPSlotTime.Location = new Point(1131, 222);
            DTPSlotTime.Name = "DTPSlotTime";
            DTPSlotTime.Size = new Size(300, 31);
            DTPSlotTime.TabIndex = 12;
            // 
            // btaddB
            // 
            btaddB.Location = new Point(892, 375);
            btaddB.Name = "btaddB";
            btaddB.Size = new Size(157, 34);
            btaddB.TabIndex = 13;
            btaddB.Text = "Add Booking";
            btaddB.UseVisualStyleBackColor = true;
            btaddB.Click += btaddB_Click;
            // 
            // btEditB
            // 
            btEditB.Location = new Point(1118, 375);
            btEditB.Name = "btEditB";
            btEditB.Size = new Size(163, 34);
            btEditB.TabIndex = 14;
            btEditB.Text = "Update Booking";
            btEditB.UseVisualStyleBackColor = true;
            btEditB.Click += btEditB_Click_1;
            // 
            // btDBooking
            // 
            btDBooking.Location = new Point(1340, 375);
            btDBooking.Name = "btDBooking";
            btDBooking.Size = new Size(158, 34);
            btDBooking.TabIndex = 15;
            btDBooking.Text = "Delete Booking";
            btDBooking.UseVisualStyleBackColor = true;
            btDBooking.Click += btDBooking_Click_1;
            // 
            // ucManageBooking
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(btDBooking);
            Controls.Add(btEditB);
            Controls.Add(btaddB);
            Controls.Add(DTPSlotTime);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(DTPSlotDate);
            Controls.Add(CBBookingStatus);
            Controls.Add(tbUserID);
            Controls.Add(tbFaciltyID);
            Controls.Add(DGVBooking);
            Name = "ucManageBooking";
            Size = new Size(1579, 438);
            ((System.ComponentModel.ISupportInitialize)DGVBooking).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView DGVBooking;
        private TextBox tbFaciltyID;
        private TextBox tbUserID;
        private MySql.Data.MySqlClient.MySqlCommand mySqlCommand1;
        private ComboBox CBBookingStatus;
        private DateTimePicker DTPSlotDate;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private DateTimePicker DTPSlotTime;
        private Button btaddB;
        private Button btEditB;
        private Button btDBooking;
    }
}
