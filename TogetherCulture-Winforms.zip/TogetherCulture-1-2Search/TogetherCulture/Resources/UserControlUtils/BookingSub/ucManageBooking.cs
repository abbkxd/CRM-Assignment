﻿using System;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace TogetherCulture.Resources.UserControlUtils.BookingSub
{
    public partial class ucManageBooking : UserControl
    {
        private string connectionString = "Server=localhost;Database=usercred;User Id=root;";

        public ucManageBooking()
        {
            InitializeComponent();
            LoadBookingData();

            
            DGVBooking.ReadOnly = true;
            DGVBooking.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            
            DGVBooking.CellClick += DGVBooking_CellClick;
        }

        private void LoadBookingData()
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = "SELECT * FROM booking";
                    MySqlDataAdapter adapter = new MySqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    DGVBooking.DataSource = dataTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading data: " + ex.Message);
                }
            }
        }

        private void DGVBooking_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = DGVBooking.Rows[e.RowIndex];

                
                tbFaciltyID.Text = selectedRow.Cells["Facility_ID"].Value?.ToString() ?? string.Empty;
                tbUserID.Text = selectedRow.Cells["User_ID"].Value?.ToString() ?? string.Empty;

                if (selectedRow.Cells["Slot_Booked"].Value != DBNull.Value)
                    DTPSlotDate.Value = Convert.ToDateTime(selectedRow.Cells["Slot_Booked"].Value);
                else
                    DTPSlotDate.Value = DateTime.Now;

                if (selectedRow.Cells["Slot_Duration"].Value != DBNull.Value)
                    DTPSlotTime.Value = DateTime.Today.AddMinutes(Convert.ToInt32(selectedRow.Cells["Slot_Duration"].Value));
                else
                    DTPSlotTime.Value = DateTime.Now;

                CBBookingStatus.SelectedItem = selectedRow.Cells["Booking_Status"].Value?.ToString();
            }
            else
            {
                MessageBox.Show("Please select a valid row.");
            }
        }

        private void btDBooking_Click_1(object sender, EventArgs e)
        {
            if (DGVBooking.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = DGVBooking.SelectedRows[0];
                string bookingID = selectedRow.Cells["Booking_ID"].Value?.ToString();

                if (!string.IsNullOrEmpty(bookingID))
                {
                    DialogResult dialogResult = MessageBox.Show("Are you sure you want to delete this booking?", "Confirm Deletion", MessageBoxButtons.YesNo);
                    if (dialogResult == DialogResult.Yes)
                    {
                        using (MySqlConnection connection = new MySqlConnection(connectionString))
                        {
                            try
                            {
                                connection.Open();
                                string query = "DELETE FROM booking WHERE Booking_ID = @BookingID";

                                using (MySqlCommand cmd = new MySqlCommand(query, connection))
                                {
                                    cmd.Parameters.AddWithValue("@BookingID", bookingID);

                                    int rowsAffected = cmd.ExecuteNonQuery();

                                    if (rowsAffected > 0)
                                        MessageBox.Show("Booking deleted successfully!");
                                    else
                                        MessageBox.Show("No rows were deleted. Please check the Booking_ID.");

                                    LoadBookingData();
                                }
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("Error deleting booking: " + ex.Message);
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Selected booking does not have a valid Booking_ID.");
                }
            }
            else
            {
                MessageBox.Show("Please select a booking to delete.");
            }
        }

        private void btEditB_Click_1(object sender, EventArgs e)
        {
            if (DGVBooking.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = DGVBooking.SelectedRows[0];
                string bookingID = selectedRow.Cells["Booking_ID"].Value?.ToString();

                if (!string.IsNullOrEmpty(bookingID))
                {
                    DialogResult dialogResult = MessageBox.Show("Are you sure you want to update this booking?", "Confirm Update", MessageBoxButtons.YesNo);
                    if (dialogResult == DialogResult.Yes)
                    {
                        using (MySqlConnection connection = new MySqlConnection(connectionString))
                        {
                            try
                            {
                                connection.Open();
                                string query = @"UPDATE booking 
                                                 SET Facility_ID = @FacilityID, 
                                                     User_ID = @UserID, 
                                                     Slot_Booked = @SlotBooked, 
                                                     Slot_Duration = @SlotDuration, 
                                                     Booking_Status = @BookingStatus 
                                                 WHERE Booking_ID = @BookingID";

                                using (MySqlCommand cmd = new MySqlCommand(query, connection))
                                {
                                    cmd.Parameters.AddWithValue("@FacilityID", string.IsNullOrWhiteSpace(tbFaciltyID.Text) ? DBNull.Value : tbFaciltyID.Text);
                                    cmd.Parameters.AddWithValue("@UserID", string.IsNullOrWhiteSpace(tbUserID.Text) ? DBNull.Value : tbUserID.Text);
                                    cmd.Parameters.AddWithValue("@SlotBooked", DTPSlotDate.Value);
                                    cmd.Parameters.AddWithValue("@SlotDuration", (int)DTPSlotTime.Value.TimeOfDay.TotalMinutes);
                                    cmd.Parameters.AddWithValue("@BookingStatus", CBBookingStatus.SelectedItem != null ? CBBookingStatus.SelectedItem.ToString() : (object)DBNull.Value);
                                    cmd.Parameters.AddWithValue("@BookingID", bookingID);

                                    int rowsAffected = cmd.ExecuteNonQuery();

                                    if (rowsAffected > 0)
                                        MessageBox.Show("Booking updated successfully!");
                                    else
                                        MessageBox.Show("No rows were updated. Please check the Booking_ID.");

                                    LoadBookingData();
                                }
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("Error updating booking: " + ex.Message);
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Selected booking does not have a valid Booking_ID.");
                }
            }
            else
            {
                MessageBox.Show("Please select a booking to update.");
            }
        }

        private void btaddB_Click(object sender, EventArgs e)
        {
            string bookingID = EntityID.GenerateId("BOOKID"); // Generate new Booking ID

            
            if (string.IsNullOrWhiteSpace(tbFaciltyID.Text) || string.IsNullOrWhiteSpace(tbUserID.Text) || CBBookingStatus.SelectedItem == null)
            {
                MessageBox.Show("Please fill all required fields and select a booking status.");
                return;
            }

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = @"INSERT INTO booking (Booking_ID, Facility_ID, User_ID, Slot_Booked, Slot_Duration, Booking_Status) 
                             VALUES (@BookingID, @FacilityID, @UserID, @SlotBooked, @SlotDuration, @BookingStatus)";

                    using (MySqlCommand cmd = new MySqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@BookingID", bookingID);
                        cmd.Parameters.AddWithValue("@FacilityID", tbFaciltyID.Text);
                        cmd.Parameters.AddWithValue("@UserID", tbUserID.Text);
                        cmd.Parameters.AddWithValue("@SlotBooked", DTPSlotDate.Value);
                        cmd.Parameters.AddWithValue("@SlotDuration", (int)DTPSlotTime.Value.TimeOfDay.TotalMinutes);
                        cmd.Parameters.AddWithValue("@BookingStatus", CBBookingStatus.SelectedItem.ToString());

                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                            MessageBox.Show("Booking added successfully!");
                        else
                            MessageBox.Show("Failed to add booking. Please try again.");

                        LoadBookingData(); 
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error adding booking: " + ex.Message);
                }
            }
        }



    }
}