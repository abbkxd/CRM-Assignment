﻿using System;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace TogetherCulture.Resources.UserControlUtils.DashboardSub
{
    public partial class upcomming_events : UserControl
    {
        public upcomming_events()
        {
            InitializeComponent();
            LoadUpcomingEvents();
        }

        private void LoadUpcomingEvents()
        {
            string connectionString = "Server=localhost;Database=usercred;User Id=root;";
            string query = "SELECT EventName AS 'Event Name', EventDate AS 'Date', EventTime AS 'Time' " +
                           "FROM events WHERE EventDate >= CURDATE() ORDER BY EventDate ASC, EventTime ASC;";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    MySqlDataAdapter adapter = new MySqlDataAdapter(query, connection);

                    DataTable eventsTable = new DataTable();
                    adapter.Fill(eventsTable);

                    Upcommingevents_datagrid.DataSource = eventsTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message, "Database Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
