﻿using System;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace TogetherCulture.Resources.UserControlUtils.DashboardSub
{
    public partial class Userinteraction : UserControl
    {
        public Userinteraction()
        {
            InitializeComponent();
            LoadUserInteractions();
        }

        
        private void LoadUserInteractions()
        {
            string connectionString = "Server=localhost;Database=usercred;User Id=root;";
            string query = @"
                SELECT ui.Username, 
                       ui.Interaction_Type, 
                       COUNT(ui.Interaction_Type) AS Interaction_Count,
                       ui.Engagement_Level, 
                       MAX(ui.Interaction_Date) AS Last_Interaction_Date
                FROM UserInteractions ui
                GROUP BY ui.Username, ui.Interaction_Type
                ORDER BY Interaction_Count DESC;";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    MySqlDataAdapter dataAdapter = new MySqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    dataAdapter.Fill(dataTable);

                    Userinteraction_datagrid.DataSource = dataTable; 
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

       
        private void Userinteraction_datagrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }
    }
}
