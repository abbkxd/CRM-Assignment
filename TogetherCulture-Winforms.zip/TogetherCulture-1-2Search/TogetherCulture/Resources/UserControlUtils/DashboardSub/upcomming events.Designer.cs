﻿namespace TogetherCulture.Resources.UserControlUtils.DashboardSub
{
    partial class upcomming_events
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Upcommingevents_datagrid = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)Upcommingevents_datagrid).BeginInit();
            SuspendLayout();
            // 
            // Upcommingevents_datagrid
            // 
            Upcommingevents_datagrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            Upcommingevents_datagrid.Location = new Point(26, 63);
            Upcommingevents_datagrid.Name = "Upcommingevents_datagrid";
            Upcommingevents_datagrid.Size = new Size(666, 257);
            Upcommingevents_datagrid.TabIndex = 0;
            // 
            // upcomming_events
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(Upcommingevents_datagrid);
            Name = "upcomming_events";
            Size = new Size(827, 341);
            ((System.ComponentModel.ISupportInitialize)Upcommingevents_datagrid).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView Upcommingevents_datagrid;
    }
}
