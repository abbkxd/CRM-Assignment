﻿namespace TogetherCulture.Resources.UserControlUtils.DashboardSub
{
    partial class Userinteraction
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Userinteraction_datagrid = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)Userinteraction_datagrid).BeginInit();
            SuspendLayout();
            // 
            // Userinteraction_datagrid
            // 
            Userinteraction_datagrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            Userinteraction_datagrid.Location = new Point(14, 29);
            Userinteraction_datagrid.Name = "Userinteraction_datagrid";
            Userinteraction_datagrid.Size = new Size(544, 287);
            Userinteraction_datagrid.TabIndex = 0;
            Userinteraction_datagrid.CellContentClick += Userinteraction_datagrid_CellContentClick;
            // 
            // Userinteraction
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(Userinteraction_datagrid);
            Name = "Userinteraction";
            Size = new Size(827, 341);
            ((System.ComponentModel.ISupportInitialize)Userinteraction_datagrid).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView Userinteraction_datagrid;
    }
}
