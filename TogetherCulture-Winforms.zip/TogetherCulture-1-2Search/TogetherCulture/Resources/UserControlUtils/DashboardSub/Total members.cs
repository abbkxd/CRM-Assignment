﻿using System;
using System.Data;
using MySql.Data.MySqlClient;
using System.Windows.Forms;

namespace TogetherCulture.Resources.UserControlUtils.DashboardSub
{
    public partial class Total_members : UserControl
    {
        
        private readonly MySqlConnection connection;

        public Total_members()
        {
            InitializeComponent();

           
            connection = new MySqlConnection("Server=localhost;Database=usercred;User Id=root;");

            
            LoadMemberData();
        }

        private void LoadMemberData()
        {
            try
            {
                
                connection.Open();

                
                string query = "SELECT Username, SubscriptionType ,Subdate, SubID FROM usersubscription";

              
                using (MySqlDataAdapter adapter = new MySqlDataAdapter(query, connection))
                {
                    DataTable dataTable = new DataTable();

                    
                    adapter.Fill(dataTable);

                    
                    if (dataTable.Rows.Count > 0)
                    {
                        dataGridView1.DataSource = dataTable;
                    }
                    else
                    {
                        MessageBox.Show("No data found in the 'Members' table.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (MySqlException ex)
            {
                
                MessageBox.Show($"Database error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                
                MessageBox.Show($"Unexpected error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }
    }
}
