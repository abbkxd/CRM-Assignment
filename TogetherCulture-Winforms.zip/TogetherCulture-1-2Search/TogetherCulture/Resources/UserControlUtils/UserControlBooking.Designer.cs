﻿namespace TogetherCulture.Resources.UserControlUtils.EventsSub
{
    partial class UserControlBooking
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserControlBooking));
            label2 = new Label();
            label1 = new Label();
            panel2 = new Panel();
            pbManageBooking = new PictureBox();
            panel3 = new Panel();
            pbViewBooking = new PictureBox();
            pnBookingUserControl = new Panel();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pbManageBooking).BeginInit();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pbViewBooking).BeginInit();
            SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 12F, FontStyle.Bold);
            label2.Location = new Point(45, 132);
            label2.Name = "label2";
            label2.Size = new Size(207, 29);
            label2.TabIndex = 9;
            label2.Text = "Manage Booking";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 12F, FontStyle.Bold);
            label1.Location = new Point(63, 132);
            label1.Name = "label1";
            label1.Size = new Size(185, 29);
            label1.TabIndex = 10;
            label1.Text = "View Bookings";
            // 
            // panel2
            // 
            panel2.Controls.Add(label2);
            panel2.Controls.Add(pbManageBooking);
            panel2.Location = new Point(235, 219);
            panel2.Name = "panel2";
            panel2.Size = new Size(305, 174);
            panel2.TabIndex = 12;
            // 
            // pbManageBooking
            // 
            pbManageBooking.Image = (Image)resources.GetObject("pbManageBooking.Image");
            pbManageBooking.Location = new Point(42, 11);
            pbManageBooking.Name = "pbManageBooking";
            pbManageBooking.Size = new Size(210, 138);
            pbManageBooking.SizeMode = PictureBoxSizeMode.Zoom;
            pbManageBooking.TabIndex = 14;
            pbManageBooking.TabStop = false;
            pbManageBooking.Click += pbManageBooking_Click;
            // 
            // panel3
            // 
            panel3.Controls.Add(label1);
            panel3.Controls.Add(pbViewBooking);
            panel3.Location = new Point(900, 219);
            panel3.Name = "panel3";
            panel3.Size = new Size(309, 174);
            panel3.TabIndex = 12;
            // 
            // pbViewBooking
            // 
            pbViewBooking.Image = (Image)resources.GetObject("pbViewBooking.Image");
            pbViewBooking.Location = new Point(27, 3);
            pbViewBooking.Name = "pbViewBooking";
            pbViewBooking.Size = new Size(237, 158);
            pbViewBooking.SizeMode = PictureBoxSizeMode.Zoom;
            pbViewBooking.TabIndex = 15;
            pbViewBooking.TabStop = false;
            pbViewBooking.Click += pbViewBooking_Click;
            // 
            // pnBookingUserControl
            // 
            pnBookingUserControl.Location = new Point(17, 426);
            pnBookingUserControl.Name = "pnBookingUserControl";
            pnBookingUserControl.Size = new Size(1579, 438);
            pnBookingUserControl.TabIndex = 13;
            // 
            // UserControlBooking
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(pnBookingUserControl);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Name = "UserControlBooking";
            Size = new Size(1612, 878);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pbManageBooking).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pbViewBooking).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private Label label2;
        private Label label1;
        private Panel panel2;
        private Panel panel3;
        private PictureBox pbViewBooking;
        private PictureBox pbManageBooking;
        private Panel pnBookingUserControl;
    }
}
