﻿namespace TogetherCulture.Resources.UserControlUtils.MembershipSub
{
    partial class AddMember
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Fname = new TextBox();
            label1 = new Label();
            Lname = new Label();
            Eml = new Label();
            PhNo = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            subscription_type = new ComboBox();
            MemTyp = new Label();
            btn_Add1 = new Button();
            AddMember1 = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)AddMember1).BeginInit();
            SuspendLayout();
            // 
            // Fname
            // 
            Fname.Location = new Point(177, 49);
            Fname.Name = "Fname";
            Fname.Size = new Size(163, 23);
            Fname.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(57, 52);
            label1.Name = "label1";
            label1.Size = new Size(75, 15);
            label1.TabIndex = 1;
            label1.Text = "FIRST NAME ";
            // 
            // Lname
            // 
            Lname.AutoSize = true;
            Lname.Location = new Point(57, 97);
            Lname.Name = "Lname";
            Lname.Size = new Size(70, 15);
            Lname.TabIndex = 2;
            Lname.Text = "LAST NAME";
            // 
            // Eml
            // 
            Eml.AutoSize = true;
            Eml.Location = new Point(57, 144);
            Eml.Name = "Eml";
            Eml.Size = new Size(41, 15);
            Eml.TabIndex = 3;
            Eml.Text = "EMAIL";
            // 
            // PhNo
            // 
            PhNo.AutoSize = true;
            PhNo.Location = new Point(57, 187);
            PhNo.Name = "PhNo";
            PhNo.Size = new Size(68, 15);
            PhNo.TabIndex = 4;
            PhNo.Text = "PHONE NO";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(177, 89);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(163, 23);
            textBox1.TabIndex = 5;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(177, 136);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(163, 23);
            textBox2.TabIndex = 6;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(177, 179);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(163, 23);
            textBox3.TabIndex = 7;
            // 
            // subscription_type
            // 
            subscription_type.FormattingEnabled = true;
            subscription_type.Items.AddRange(new object[] { "Creative Workspace member", "KeyAccess member", "Community member" });
            subscription_type.Location = new Point(177, 222);
            subscription_type.Name = "subscription_type";
            subscription_type.Size = new Size(163, 23);
            subscription_type.TabIndex = 8;
            subscription_type.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // MemTyp
            // 
            MemTyp.AutoSize = true;
            MemTyp.Location = new Point(57, 225);
            MemTyp.Name = "MemTyp";
            MemTyp.Size = new Size(109, 15);
            MemTyp.TabIndex = 9;
            MemTyp.Text = "MEMBERSHIP TYPE";
            // 
            // btn_Add1
            // 
            btn_Add1.Location = new Point(177, 279);
            btn_Add1.Margin = new Padding(2, 2, 2, 2);
            btn_Add1.Name = "btn_Add1";
            btn_Add1.Size = new Size(163, 27);
            btn_Add1.TabIndex = 12;
            btn_Add1.Text = "ADD";
            btn_Add1.Click += btn_Add1_Click;
            // 
            // AddMember1
            // 
            AddMember1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            AddMember1.Location = new Point(513, 52);
            AddMember1.Name = "AddMember1";
            AddMember1.RowHeadersWidth = 62;
            AddMember1.Size = new Size(467, 195);
            AddMember1.TabIndex = 11;
            // 
            // AddMember
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(AddMember1);
            Controls.Add(btn_Add1);
            Controls.Add(MemTyp);
            Controls.Add(subscription_type);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(PhNo);
            Controls.Add(Eml);
            Controls.Add(Lname);
            Controls.Add(label1);
            Controls.Add(Fname);
            Name = "AddMember";
            Size = new Size(1110, 348);
            Load += AddMember_Load;
            ((System.ComponentModel.ISupportInitialize)AddMember1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox Fname;
        private Label label1;
        private Label Lname;
        private Label Eml;
        private Label PhNo;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private ComboBox subscription_type;
        private Label MemTyp;
        private Button btn_Add1;
        private DataGridView AddMember1;
    }
}
