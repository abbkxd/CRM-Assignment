﻿using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Data;

namespace TogetherCulture.Resources.UserControlUtils.MembershipSub
{
    public partial class AddMember : UserControl
    {
        private string connectionString = "Server=localhost;Database=usercred;User Id=root;";

        public AddMember()
        {
            InitializeComponent();
        }

        private void AddMember_Load(object sender, EventArgs e)
        {
            LoadDataGrid();
        }

        private void LoadDataGrid()
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = "SELECT * FROM members";
                    MySqlDataAdapter dataAdapter = new MySqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    dataAdapter.Fill(dataTable);
                    AddMember1.DataSource = dataTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading data: " + ex.Message);
                }
            }
        }

        private void btn_Add1_Click(object sender, EventArgs e)
        {
            
            string firstName = Fname.Text;
            string lastName = textBox1.Text;
            string email = textBox2.Text;
            string phoneNumber = textBox3.Text;
            string subscriptionType = subscription_type.SelectedItem?.ToString();

            
            if (string.IsNullOrEmpty(firstName) || string.IsNullOrEmpty(lastName) || string.IsNullOrEmpty(email) || string.IsNullOrEmpty(phoneNumber) || string.IsNullOrEmpty(subscriptionType))
            {
                MessageBox.Show("All fields must be filled out");
                return;
            }

           
            if (!IsValidEmail(email))
            {
                MessageBox.Show("Please enter a valid email address.");
                return;
            }

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = "INSERT INTO members (first_name, last_name, email, ph_no, subscription_type) VALUES (@FirstName, @LastName, @Email, @PhoneNumber, @SubscriptionType)";
                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@FirstName", firstName);
                        command.Parameters.AddWithValue("@LastName", lastName);
                        command.Parameters.AddWithValue("@Email", email);
                        command.Parameters.AddWithValue("@PhoneNumber", phoneNumber);
                        command.Parameters.AddWithValue("@SubscriptionType", subscriptionType);

                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Member added successfully");
                            LoadDataGrid();
                        }
                        else
                        {
                            MessageBox.Show("Failed to add member. Please try again.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error adding member: " + ex.Message);
                    
                    Console.WriteLine("Error details: " + ex.ToString());
                }
            }
        }

        private bool IsValidEmail(string email)
        {
            try
            {
                var mailAddress = new System.Net.Mail.MailAddress(email);
                return mailAddress.Address == email;
            }
            catch
            {
                return false;
            }
        }

        
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        
    }
}
