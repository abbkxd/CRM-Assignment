﻿namespace TogetherCulture.Resources.UserControlUtils.MembershipSub
{
    partial class ViewMemberDetails
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            MembersDetails = new DataGridView();
            btn_Delete = new Button();
            btn_Edit = new Button();
            Fname = new TextBox();
            Lname = new TextBox();
            PhNo = new TextBox();
            Email = new TextBox();
            Lbl_Fn = new Label();
            Lbl_Ln = new Label();
            Lbl_Ph = new Label();
            Lbl_Eml = new Label();
            Lbl_Mtyp = new Label();
            subscription_type = new TextBox();
            ((System.ComponentModel.ISupportInitialize)MembersDetails).BeginInit();
            SuspendLayout();
            // 
            // MembersDetails
            // 
            MembersDetails.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            MembersDetails.Location = new Point(14, 44);
            MembersDetails.Name = "MembersDetails";
            MembersDetails.Size = new Size(479, 265);
            MembersDetails.TabIndex = 0;
            // 
            // btn_Delete
            // 
            btn_Delete.Location = new Point(688, 283);
            btn_Delete.Name = "btn_Delete";
            btn_Delete.Size = new Size(89, 26);
            btn_Delete.TabIndex = 1;
            btn_Delete.Text = "DELETE";
            btn_Delete.UseVisualStyleBackColor = true;
            btn_Delete.Click += btn_Delete_Click_1;
            // 
            // btn_Edit
            // 
            btn_Edit.Location = new Point(569, 283);
            btn_Edit.Name = "btn_Edit";
            btn_Edit.Size = new Size(89, 26);
            btn_Edit.TabIndex = 2;
            btn_Edit.Text = "EDIT";
            btn_Edit.UseVisualStyleBackColor = true;
            btn_Edit.Click += btn_Edit_Click_1;
            // 
            // Fname
            // 
            Fname.Location = new Point(677, 44);
            Fname.Name = "Fname";
            Fname.Size = new Size(100, 23);
            Fname.TabIndex = 3;
            // 
            // Lname
            // 
            Lname.Location = new Point(677, 84);
            Lname.Name = "Lname";
            Lname.Size = new Size(100, 23);
            Lname.TabIndex = 4;
            // 
            // PhNo
            // 
            PhNo.Location = new Point(677, 127);
            PhNo.Name = "PhNo";
            PhNo.Size = new Size(100, 23);
            PhNo.TabIndex = 5;
            // 
            // Email
            // 
            Email.Location = new Point(677, 170);
            Email.Name = "Email";
            Email.Size = new Size(100, 23);
            Email.TabIndex = 6;
            // 
            // Lbl_Fn
            // 
            Lbl_Fn.AutoSize = true;
            Lbl_Fn.Location = new Point(549, 44);
            Lbl_Fn.Name = "Lbl_Fn";
            Lbl_Fn.Size = new Size(75, 15);
            Lbl_Fn.TabIndex = 7;
            Lbl_Fn.Text = "FIRST NAME ";
            // 
            // Lbl_Ln
            // 
            Lbl_Ln.AutoSize = true;
            Lbl_Ln.Location = new Point(549, 84);
            Lbl_Ln.Name = "Lbl_Ln";
            Lbl_Ln.Size = new Size(73, 15);
            Lbl_Ln.TabIndex = 8;
            Lbl_Ln.Text = "LAST NAME ";
            // 
            // Lbl_Ph
            // 
            Lbl_Ph.AutoSize = true;
            Lbl_Ph.Location = new Point(549, 127);
            Lbl_Ph.Name = "Lbl_Ph";
            Lbl_Ph.Size = new Size(98, 15);
            Lbl_Ph.TabIndex = 9;
            Lbl_Ph.Text = "PHONE NUMBER";
            // 
            // Lbl_Eml
            // 
            Lbl_Eml.AutoSize = true;
            Lbl_Eml.Location = new Point(549, 170);
            Lbl_Eml.Name = "Lbl_Eml";
            Lbl_Eml.Size = new Size(41, 15);
            Lbl_Eml.TabIndex = 10;
            Lbl_Eml.Text = "EMAIL";
            // 
            // Lbl_Mtyp
            // 
            Lbl_Mtyp.AutoSize = true;
            Lbl_Mtyp.Location = new Point(549, 217);
            Lbl_Mtyp.Name = "Lbl_Mtyp";
            Lbl_Mtyp.Size = new Size(109, 15);
            Lbl_Mtyp.TabIndex = 11;
            Lbl_Mtyp.Text = "MEMBERSHIP TYPE";
            // 
            // subscription_type
            // 
            subscription_type.Location = new Point(677, 214);
            subscription_type.Name = "subscription_type";
            subscription_type.Size = new Size(100, 23);
            subscription_type.TabIndex = 12;
            // 
            // ViewMemberDetails
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(subscription_type);
            Controls.Add(Lbl_Mtyp);
            Controls.Add(Lbl_Eml);
            Controls.Add(Lbl_Ph);
            Controls.Add(Lbl_Ln);
            Controls.Add(Lbl_Fn);
            Controls.Add(Email);
            Controls.Add(PhNo);
            Controls.Add(Lname);
            Controls.Add(Fname);
            Controls.Add(btn_Edit);
            Controls.Add(btn_Delete);
            Controls.Add(MembersDetails);
            Name = "ViewMemberDetails";
            Size = new Size(1110, 348);
            ((System.ComponentModel.ISupportInitialize)MembersDetails).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView MembersDetails;
        private Button btn_Delete;
        private Button btn_Edit;
        private TextBox Fname;
        private TextBox Lname;
        private TextBox PhNo;
        private TextBox Email;
        private Label Lbl_Fn;
        private Label Lbl_Ln;
        private Label Lbl_Ph;
        private Label Lbl_Eml;
        private Label Lbl_Mtyp;
        private TextBox subscription_type;
    }
}
