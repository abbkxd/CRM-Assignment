﻿using System;
using System.Data;
using MySql.Data.MySqlClient;
using System.Windows.Forms;

namespace TogetherCulture.Resources.UserControlUtils.MembershipSub
{
    public partial class ViewMemberDetails : UserControl
    {
        private string connectionString = "Server=localhost;Database=usercred;User Id=root;";

        public ViewMemberDetails()
        {
            InitializeComponent();
            ConfigureDataGridView();
            LoadMemberDetails();
            MembersDetails.CellClick += MembersDetails_CellClick;
        }

        private void ConfigureDataGridView()
        {
            MembersDetails.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            MembersDetails.MultiSelect = false;
            MembersDetails.ReadOnly = true;
            MembersDetails.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void LoadMemberDetails()
        {
            try
            {
                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT * FROM Members";
                    using (MySqlDataAdapter adapter = new MySqlDataAdapter(query, connection))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        MembersDetails.DataSource = dt;

                        if (MembersDetails.Rows.Count > 0)
                            MembersDetails.Rows[0].Selected = true;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message);
            }
        }

        private void MembersDetails_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                try
                {
                    DataGridViewRow row = MembersDetails.Rows[e.RowIndex];
                    Fname.Text = row.Cells["first_name"].Value?.ToString() ?? string.Empty;
                    Lname.Text = row.Cells["last_name"].Value?.ToString() ?? string.Empty;
                    PhNo.Text = row.Cells["ph_no"].Value?.ToString() ?? string.Empty;
                    Email.Text = row.Cells["email"].Value?.ToString() ?? string.Empty;
                    subscription_type.Text = row.Cells["subscription_type"].Value?.ToString() ?? string.Empty;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error selecting row: " + ex.Message);
                }
            }
        }

        private void btn_Edit_Click_1(object sender, EventArgs e)
        {
            if (MembersDetails.SelectedRows.Count > 0)
            {
                try
                {
                    string memberId = MembersDetails.SelectedRows[0].Cells["member_id"].Value?.ToString();
                    if (string.IsNullOrEmpty(memberId))
                    {
                        MessageBox.Show("Unable to determine the selected member's ID.");
                        return;
                    }

                    if (string.IsNullOrWhiteSpace(Fname.Text) || string.IsNullOrWhiteSpace(Lname.Text))
                    {
                        MessageBox.Show("First Name and Last Name cannot be empty.");
                        return;
                    }

                    using (var connection = new MySqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "UPDATE Members SET first_name = @FirstName, last_name = @LastName, ph_no = @Phone, email = @Email, subscription_type = @Subscription WHERE member_id = @MemberID";
                        using (MySqlCommand cmd = new MySqlCommand(query, connection))
                        {
                            cmd.Parameters.AddWithValue("@FirstName", Fname.Text);
                            cmd.Parameters.AddWithValue("@LastName", Lname.Text);
                            cmd.Parameters.AddWithValue("@Phone", PhNo.Text);
                            cmd.Parameters.AddWithValue("@Email", Email.Text);
                            cmd.Parameters.AddWithValue("@Subscription", subscription_type.Text);
                            cmd.Parameters.AddWithValue("@MemberID", memberId);

                            int rowsAffected = cmd.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Details updated successfully.");
                                LoadMemberDetails();
                            }
                            else
                            {
                                MessageBox.Show("No changes were made. Check the details and try again.");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error updating data: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Please select a member to edit.");
            }
        }

        private void btn_Delete_Click_1(object sender, EventArgs e)
        {
            if (MembersDetails.SelectedRows.Count > 0)
            {
                try
                {
                    string memberId = MembersDetails.SelectedRows[0].Cells["member_id"].Value?.ToString();
                    if (string.IsNullOrEmpty(memberId))
                    {
                        MessageBox.Show("Unable to determine the selected member's ID.");
                        return;
                    }

                    DialogResult result = MessageBox.Show("Are you sure you want to delete this member?", "Confirm Deletion", MessageBoxButtons.YesNo);
                    if (result == DialogResult.No) return;

                    using (var connection = new MySqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "DELETE FROM Members WHERE member_id = @MemberID";
                        using (MySqlCommand cmd = new MySqlCommand(query, connection))
                        {
                            cmd.Parameters.AddWithValue("@MemberID", memberId);

                            int rowsAffected = cmd.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Member deleted successfully.");
                                LoadMemberDetails();
                            }
                            else
                            {
                                MessageBox.Show("Failed to delete the member. The record might not exist.");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error deleting data: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Please select a member to delete.");
            }
        }

      
    }
}
