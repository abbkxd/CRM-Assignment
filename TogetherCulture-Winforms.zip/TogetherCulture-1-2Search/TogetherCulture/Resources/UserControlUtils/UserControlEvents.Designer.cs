﻿namespace TogetherCulture.Resources.UserControlUtils
{
    partial class UserControlEvents
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            pictureBox1 = new PictureBox();
            label2 = new Label();
            pnAddEvent = new Panel();
            pnManageEvent = new Panel();
            label3 = new Label();
            pictureBox2 = new PictureBox();
            pnEvent = new Panel();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            pnAddEvent.SuspendLayout();
            pnManageEvent.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            pnEvent.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 16F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(148, 91);
            label1.Name = "label1";
            label1.Size = new Size(121, 37);
            label1.TabIndex = 0;
            label1.Text = "Events";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.add_event;
            pictureBox1.Location = new Point(58, 20);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(311, 193);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 16F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(104, 226);
            label2.Name = "label2";
            label2.Size = new Size(191, 37);
            label2.TabIndex = 2;
            label2.Text = "Add Events";
            // 
            // pnAddEvent
            // 
            pnAddEvent.Controls.Add(pictureBox1);
            pnAddEvent.Controls.Add(label2);
            pnAddEvent.Location = new Point(274, 128);
            pnAddEvent.Name = "pnAddEvent";
            pnAddEvent.Size = new Size(435, 308);
            pnAddEvent.TabIndex = 3;
            pnAddEvent.Paint += panel1_Paint;
            // 
            // pnManageEvent
            // 
            pnManageEvent.Controls.Add(label3);
            pnManageEvent.Controls.Add(pictureBox2);
            pnManageEvent.Location = new Point(740, 128);
            pnManageEvent.Name = "pnManageEvent";
            pnManageEvent.Size = new Size(435, 308);
            pnManageEvent.TabIndex = 4;
            pnManageEvent.Paint += pnManageEvent_Paint;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 16F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(92, 226);
            label3.Name = "label3";
            label3.Size = new Size(249, 37);
            label3.TabIndex = 5;
            label3.Text = "Manage Events";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.manageevent1;
            pictureBox2.Location = new Point(65, 20);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(311, 193);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 5;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // pnEvent
            // 
            pnEvent.Controls.Add(pnAddEvent);
            pnEvent.Controls.Add(pnManageEvent);
            pnEvent.Location = new Point(3, 171);
            pnEvent.Name = "pnEvent";
            pnEvent.Size = new Size(1612, 914);
            pnEvent.TabIndex = 5;
            // 
            // UserControlEvents
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(pnEvent);
            Controls.Add(label1);
            Name = "UserControlEvents";
            Size = new Size(1627, 1100);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            pnAddEvent.ResumeLayout(false);
            pnAddEvent.PerformLayout();
            pnManageEvent.ResumeLayout(false);
            pnManageEvent.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            pnEvent.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private PictureBox pictureBox1;
        private Label label2;
        private Panel pnAddEvent;
        private Panel pnManageEvent;
        private Label label3;
        private PictureBox pictureBox2;
        private Panel pnEvent;
    }
}
