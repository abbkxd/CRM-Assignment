﻿namespace TogetherCulture.Resources.UserControlUtils
{
    partial class UserControlAnalytics
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserControlAnalytics));
            label1 = new Label();
            pictureBox1 = new PictureBox();
            pbUser = new PictureBox();
            pbEvent = new PictureBox();
            pbBooking = new PictureBox();
            panelAnalytics = new Panel();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbUser).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbEvent).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbBooking).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(157, 154);
            label1.Name = "label1";
            label1.Size = new Size(175, 43);
            label1.TabIndex = 1;
            label1.Text = "Analytics";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(20, 132);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(181, 110);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 3;
            pictureBox1.TabStop = false;
            // 
            // pbUser
            // 
            pbUser.Image = (Image)resources.GetObject("pbUser.Image");
            pbUser.Location = new Point(237, 327);
            pbUser.Name = "pbUser";
            pbUser.Size = new Size(254, 163);
            pbUser.SizeMode = PictureBoxSizeMode.Zoom;
            pbUser.TabIndex = 7;
            pbUser.TabStop = false;
            pbUser.Click += pbUser_Click;
            // 
            // pbEvent
            // 
            pbEvent.Image = (Image)resources.GetObject("pbEvent.Image");
            pbEvent.Location = new Point(714, 327);
            pbEvent.Name = "pbEvent";
            pbEvent.Size = new Size(254, 163);
            pbEvent.SizeMode = PictureBoxSizeMode.Zoom;
            pbEvent.TabIndex = 8;
            pbEvent.TabStop = false;
            pbEvent.Click += pbEvent_Click;
            // 
            // pbBooking
            // 
            pbBooking.Image = (Image)resources.GetObject("pbBooking.Image");
            pbBooking.Location = new Point(1161, 327);
            pbBooking.Name = "pbBooking";
            pbBooking.Size = new Size(254, 163);
            pbBooking.SizeMode = PictureBoxSizeMode.Zoom;
            pbBooking.TabIndex = 9;
            pbBooking.TabStop = false;
            pbBooking.Click += pbBooking_Click;
            // 
            // panelAnalytics
            // 
            panelAnalytics.Location = new Point(34, 538);
            panelAnalytics.Name = "panelAnalytics";
            panelAnalytics.Size = new Size(1563, 535);
            panelAnalytics.TabIndex = 10;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(303, 465);
            label3.Name = "label3";
            label3.Size = new Size(133, 25);
            label3.TabIndex = 11;
            label3.Text = "User Analytics";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(776, 465);
            label4.Name = "label4";
            label4.Size = new Size(143, 25);
            label4.TabIndex = 12;
            label4.Text = "Event Analytics";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(1219, 465);
            label5.Name = "label5";
            label5.Size = new Size(166, 25);
            label5.TabIndex = 13;
            label5.Text = "Booking Analytics";
            // 
            // UserControlAnalytics
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(panelAnalytics);
            Controls.Add(pbBooking);
            Controls.Add(pbEvent);
            Controls.Add(pbUser);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            Name = "UserControlAnalytics";
            Size = new Size(1627, 1100);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbUser).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbEvent).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbBooking).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private PictureBox pictureBox1;
        private PictureBox pbUser;
        private PictureBox pbEvent;
        private PictureBox pbBooking;
        private Panel panelAnalytics;
        private Label label3;
        private Label label4;
        private Label label5;
    }
}
