﻿namespace TogetherCulture.Resources.UserControlUtils.AnalyticsSub
{
    partial class UCuserAnalytics
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            tbTotalUsers = new TextBox();
            DGVActiveUsers = new DataGridView();
            DGVUserInterest = new DataGridView();
            label3 = new Label();
            DGVSubType = new DataGridView();
            label4 = new Label();
            DGVsubcount = new DataGridView();
            label5 = new Label();
            ((System.ComponentModel.ISupportInitialize)DGVActiveUsers).BeginInit();
            ((System.ComponentModel.ISupportInitialize)DGVUserInterest).BeginInit();
            ((System.ComponentModel.ISupportInitialize)DGVSubType).BeginInit();
            ((System.ComponentModel.ISupportInitialize)DGVsubcount).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(1245, 34);
            label1.Name = "label1";
            label1.Size = new Size(97, 25);
            label1.TabIndex = 1;
            label1.Text = "Total Users";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(1172, 117);
            label2.Name = "label2";
            label2.Size = new Size(154, 25);
            label2.TabIndex = 2;
            label2.Text = "Most Active Users";
            // 
            // tbTotalUsers
            // 
            tbTotalUsers.BackColor = Color.White;
            tbTotalUsers.Enabled = false;
            tbTotalUsers.Location = new Point(1348, 31);
            tbTotalUsers.Name = "tbTotalUsers";
            tbTotalUsers.Size = new Size(99, 31);
            tbTotalUsers.TabIndex = 3;
            tbTotalUsers.TextChanged += tbTotalUsers_TextChanged;
            // 
            // DGVActiveUsers
            // 
            DGVActiveUsers.AllowUserToAddRows = false;
            DGVActiveUsers.AllowUserToDeleteRows = false;
            DGVActiveUsers.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DGVActiveUsers.Location = new Point(1055, 156);
            DGVActiveUsers.Name = "DGVActiveUsers";
            DGVActiveUsers.ReadOnly = true;
            DGVActiveUsers.RowHeadersWidth = 62;
            DGVActiveUsers.Size = new Size(412, 337);
            DGVActiveUsers.TabIndex = 4;
            // 
            // DGVUserInterest
            // 
            DGVUserInterest.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DGVUserInterest.Location = new Point(588, 156);
            DGVUserInterest.Name = "DGVUserInterest";
            DGVUserInterest.RowHeadersWidth = 62;
            DGVUserInterest.Size = new Size(285, 337);
            DGVUserInterest.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(601, 117);
            label3.Name = "label3";
            label3.Size = new Size(244, 25);
            label3.TabIndex = 6;
            label3.Text = "Most Common User interests";
            // 
            // DGVSubType
            // 
            DGVSubType.AllowUserToAddRows = false;
            DGVSubType.AllowUserToDeleteRows = false;
            DGVSubType.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DGVSubType.Location = new Point(33, 304);
            DGVSubType.Name = "DGVSubType";
            DGVSubType.ReadOnly = true;
            DGVSubType.RowHeadersWidth = 62;
            DGVSubType.Size = new Size(362, 171);
            DGVSubType.TabIndex = 7;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(117, 276);
            label4.Name = "label4";
            label4.Size = new Size(228, 25);
            label4.TabIndex = 8;
            label4.Text = "Subscription Type Analytics";
            // 
            // DGVsubcount
            // 
            DGVsubcount.AllowUserToAddRows = false;
            DGVsubcount.AllowUserToDeleteRows = false;
            DGVsubcount.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DGVsubcount.Location = new Point(33, 156);
            DGVsubcount.Name = "DGVsubcount";
            DGVsubcount.ReadOnly = true;
            DGVsubcount.RowHeadersWidth = 62;
            DGVsubcount.Size = new Size(362, 100);
            DGVsubcount.TabIndex = 9;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(145, 117);
            label5.Name = "label5";
            label5.Size = new Size(176, 25);
            label5.TabIndex = 10;
            label5.Text = "Unsub/Sub Analytics";
            // 
            // UCuserAnalytics
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(label5);
            Controls.Add(DGVsubcount);
            Controls.Add(label4);
            Controls.Add(DGVSubType);
            Controls.Add(label3);
            Controls.Add(DGVUserInterest);
            Controls.Add(DGVActiveUsers);
            Controls.Add(tbTotalUsers);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "UCuserAnalytics";
            Size = new Size(1563, 535);
            ((System.ComponentModel.ISupportInitialize)DGVActiveUsers).EndInit();
            ((System.ComponentModel.ISupportInitialize)DGVUserInterest).EndInit();
            ((System.ComponentModel.ISupportInitialize)DGVSubType).EndInit();
            ((System.ComponentModel.ISupportInitialize)DGVsubcount).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label1;
        private Label label2;
        private TextBox tbTotalUsers;
        private DataGridView DGVActiveUsers;
        private DataGridView DGVUserInterest;
        private Label label3;
        private DataGridView DGVSubType;
        private Label label4;
        private DataGridView DGVsubcount;
        private Label label5;
    }
}
