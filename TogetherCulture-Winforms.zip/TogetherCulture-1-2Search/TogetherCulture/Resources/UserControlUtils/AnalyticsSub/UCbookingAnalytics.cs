﻿using System;
using System.Data;
using MySql.Data.MySqlClient;
using System.Windows.Forms;

namespace TogetherCulture.Resources.UserControlUtils.AnalyticsSub
{
    public partial class UCbookingAnalytics : UserControl
    {
        private string connectionString = "Server=localhost;Database=usercred;User Id=root;"; 

        public UCbookingAnalytics()
        {
            InitializeComponent();
            LoadBookingAnalytics();
        }

        private void LoadBookingAnalytics()
        {
            LoadBookingsByUser();
            LoadBookingsByFacility();
            LoadVisitorCheckInOut();
            LoadBookingStatusBreakdown();
        }

        private void LoadBookingsByUser()
        {
            string query = @"
                SELECT User_ID, COUNT(*) AS BookingCount
                FROM booking
                GROUP BY User_ID
                ORDER BY BookingCount DESC;
            ";

            DataTable dt = GetData(query);
            DGVUserBooking.DataSource = dt;
        }

        private void LoadBookingsByFacility()
        {
            string query = @"
                SELECT Facility_ID, COUNT(*) AS BookingCount
                FROM booking
                GROUP BY Facility_ID
                ORDER BY BookingCount DESC;
            ";

            DataTable dt = GetData(query);
            DGVFacility.DataSource = dt;
        }

        private void LoadVisitorCheckInOut()
        {
            string query = @"
                SELECT V.Visitorid, V.username, V.Facility_ID, V.Check_in_Time, V.Check_out_Time, V.Duration_of_Stay
                FROM Visitor V
                JOIN booking B ON V.Booking_ID = B.Booking_ID;
            ";

            DataTable dt = GetData(query);
            DGVVistor.DataSource = dt;
        }

        private void LoadBookingStatusBreakdown()
        {
            string query = @"
                SELECT Booking_Status, COUNT(*) AS StatusCount
                FROM booking
                GROUP BY Booking_Status;
            ";

            DataTable dt = GetData(query);
            DGVBookingBreakdown.DataSource = dt;
        }

        private DataTable GetData(string query)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                MySqlDataAdapter adapter = new MySqlDataAdapter(query, connection);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                return dt;
            }
        }
    }
}
