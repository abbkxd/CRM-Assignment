﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace TogetherCulture.Resources.UserControlUtils.AnalyticsSub
{
    public partial class UCuserAnalytics : UserControl
    {
        public UCuserAnalytics()
        {
            InitializeComponent();
            TotalUsers();
            LoadSubAndUnsubCounts();
            LoadSubscriptionTypeAnalytics();
            LoadMostCommonUserTags();
            LoadMostActiveUsers();

        }
        private string _connectionString = "Server=localhost;Database=usercred;User Id=root;";

        private void TotalUsers()
        {
            string query = "SELECT COUNT(*) AS TotalUsers FROM users";
            using (MySqlConnection connection = new MySqlConnection(_connectionString))
            {
                connection.Open();
                MySqlCommand cmd = new MySqlCommand(query, connection);
                int totalUsers = Convert.ToInt32(cmd.ExecuteScalar());
                tbTotalUsers.Text = totalUsers.ToString();
            }


        }

        private void LoadSubAndUnsubCounts()
        {
            string query = @"
        SELECT 
            IFNULL((
                SELECT COUNT(*) FROM usersubscription WHERE SubscriptionType IS NOT NULL
            ), 0) AS SubscribedCount,
            IFNULL((
                SELECT COUNT(*) FROM users WHERE Username NOT IN (SELECT Username FROM usersubscription)
            ), 0) AS UnsubscribedCount
    ";

            using (MySqlConnection connection = new MySqlConnection(_connectionString))
            {
                connection.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter(query, connection);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                DGVsubcount.DataSource = dt;
            }
        }


        private void LoadSubscriptionTypeAnalytics()
        {
            string query = "SELECT SubscriptionType, COUNT(*) AS Count FROM usersubscription GROUP BY SubscriptionType";
            using (MySqlConnection connection = new MySqlConnection(_connectionString))
            {
                connection.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter(query, connection);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                DGVSubType.DataSource = dt;
            }
        }

        private void LoadMostCommonUserTags()
        {
            string query = "SELECT interest_tag, COUNT(*) AS Count FROM user_interests GROUP BY interest_tag ORDER BY Count DESC";
            using (MySqlConnection connection = new MySqlConnection(_connectionString))
            {
                connection.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter(query, connection);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                DGVUserInterest.DataSource = dt;
            }
        }

        private void tbTotalUsers_TextChanged(object sender, EventArgs e)
        {

        }


        private void LoadMostActiveUsers()
        {
            string query = @"
        SELECT Username, COUNT(*) AS InteractionCount
        FROM UserInteractions
        GROUP BY Username
        ORDER BY InteractionCount DESC;
    ";

            using (MySqlConnection connection = new MySqlConnection(_connectionString))
            {
                connection.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter(query, connection);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                DGVActiveUsers.DataSource = dt;
            }
        }




    }
}
