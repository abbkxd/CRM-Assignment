﻿namespace TogetherCulture.Resources.UserControlUtils.AnalyticsSub
{
    partial class UCbookingAnalytics
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DGVUserBooking = new DataGridView();
            DGVFacility = new DataGridView();
            DGVVistor = new DataGridView();
            DGVBookingBreakdown = new DataGridView();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            ((System.ComponentModel.ISupportInitialize)DGVUserBooking).BeginInit();
            ((System.ComponentModel.ISupportInitialize)DGVFacility).BeginInit();
            ((System.ComponentModel.ISupportInitialize)DGVVistor).BeginInit();
            ((System.ComponentModel.ISupportInitialize)DGVBookingBreakdown).BeginInit();
            SuspendLayout();
            // 
            // DGVUserBooking
            // 
            DGVUserBooking.AllowUserToAddRows = false;
            DGVUserBooking.AllowUserToDeleteRows = false;
            DGVUserBooking.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DGVUserBooking.Location = new Point(16, 170);
            DGVUserBooking.Name = "DGVUserBooking";
            DGVUserBooking.ReadOnly = true;
            DGVUserBooking.RowHeadersWidth = 62;
            DGVUserBooking.Size = new Size(360, 320);
            DGVUserBooking.TabIndex = 0;
            // 
            // DGVFacility
            // 
            DGVFacility.AllowUserToAddRows = false;
            DGVFacility.AllowUserToDeleteRows = false;
            DGVFacility.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DGVFacility.Location = new Point(404, 170);
            DGVFacility.Name = "DGVFacility";
            DGVFacility.ReadOnly = true;
            DGVFacility.RowHeadersWidth = 62;
            DGVFacility.Size = new Size(360, 320);
            DGVFacility.TabIndex = 1;
            // 
            // DGVVistor
            // 
            DGVVistor.AllowUserToAddRows = false;
            DGVVistor.AllowUserToDeleteRows = false;
            DGVVistor.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DGVVistor.Location = new Point(796, 170);
            DGVVistor.Name = "DGVVistor";
            DGVVistor.ReadOnly = true;
            DGVVistor.RowHeadersWidth = 62;
            DGVVistor.Size = new Size(360, 320);
            DGVVistor.TabIndex = 2;
            // 
            // DGVBookingBreakdown
            // 
            DGVBookingBreakdown.AllowUserToAddRows = false;
            DGVBookingBreakdown.AllowUserToDeleteRows = false;
            DGVBookingBreakdown.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DGVBookingBreakdown.Location = new Point(1181, 170);
            DGVBookingBreakdown.Name = "DGVBookingBreakdown";
            DGVBookingBreakdown.ReadOnly = true;
            DGVBookingBreakdown.RowHeadersWidth = 62;
            DGVBookingBreakdown.Size = new Size(360, 164);
            DGVBookingBreakdown.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(114, 130);
            label1.Name = "label1";
            label1.Size = new Size(126, 25);
            label1.TabIndex = 4;
            label1.Text = "User Bookings";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(502, 130);
            label2.Name = "label2";
            label2.Size = new Size(168, 25);
            label2.TabIndex = 5;
            label2.Text = "Bookings by Facility";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(862, 130);
            label3.Name = "label3";
            label3.Size = new Size(223, 25);
            label3.TabIndex = 6;
            label3.Text = "Visitor Check-in/Check-out";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(1250, 130);
            label4.Name = "label4";
            label4.Size = new Size(224, 25);
            label4.TabIndex = 7;
            label4.Text = "Booking Status Breakdown";
            // 
            // UCbookingAnalytics
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(DGVBookingBreakdown);
            Controls.Add(DGVVistor);
            Controls.Add(DGVFacility);
            Controls.Add(DGVUserBooking);
            Name = "UCbookingAnalytics";
            Size = new Size(1563, 535);
            ((System.ComponentModel.ISupportInitialize)DGVUserBooking).EndInit();
            ((System.ComponentModel.ISupportInitialize)DGVFacility).EndInit();
            ((System.ComponentModel.ISupportInitialize)DGVVistor).EndInit();
            ((System.ComponentModel.ISupportInitialize)DGVBookingBreakdown).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView DGVUserBooking;
        private DataGridView DGVFacility;
        private DataGridView DGVVistor;
        private DataGridView DGVBookingBreakdown;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
    }
}
