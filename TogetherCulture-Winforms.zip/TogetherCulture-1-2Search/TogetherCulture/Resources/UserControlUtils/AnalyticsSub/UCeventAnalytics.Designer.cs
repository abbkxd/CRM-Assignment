﻿namespace TogetherCulture.Resources.UserControlUtils.AnalyticsSub
{
    partial class UCeventAnalytics
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DGVHosts = new DataGridView();
            DGVParticpation = new DataGridView();
            DGVEventsTrend = new DataGridView();
            DGVTimeSlots = new DataGridView();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            ((System.ComponentModel.ISupportInitialize)DGVHosts).BeginInit();
            ((System.ComponentModel.ISupportInitialize)DGVParticpation).BeginInit();
            ((System.ComponentModel.ISupportInitialize)DGVEventsTrend).BeginInit();
            ((System.ComponentModel.ISupportInitialize)DGVTimeSlots).BeginInit();
            SuspendLayout();
            // 
            // DGVHosts
            // 
            DGVHosts.AllowUserToAddRows = false;
            DGVHosts.AllowUserToDeleteRows = false;
            DGVHosts.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DGVHosts.Location = new Point(87, 92);
            DGVHosts.Name = "DGVHosts";
            DGVHosts.ReadOnly = true;
            DGVHosts.RowHeadersWidth = 62;
            DGVHosts.Size = new Size(343, 155);
            DGVHosts.TabIndex = 0;
            // 
            // DGVParticpation
            // 
            DGVParticpation.AllowUserToAddRows = false;
            DGVParticpation.AllowUserToDeleteRows = false;
            DGVParticpation.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DGVParticpation.Location = new Point(600, 92);
            DGVParticpation.Name = "DGVParticpation";
            DGVParticpation.ReadOnly = true;
            DGVParticpation.RowHeadersWidth = 62;
            DGVParticpation.Size = new Size(360, 406);
            DGVParticpation.TabIndex = 1;
            // 
            // DGVEventsTrend
            // 
            DGVEventsTrend.AllowUserToAddRows = false;
            DGVEventsTrend.AllowUserToDeleteRows = false;
            DGVEventsTrend.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DGVEventsTrend.Location = new Point(1071, 92);
            DGVEventsTrend.Name = "DGVEventsTrend";
            DGVEventsTrend.ReadOnly = true;
            DGVEventsTrend.RowHeadersWidth = 62;
            DGVEventsTrend.Size = new Size(360, 406);
            DGVEventsTrend.TabIndex = 2;
            // 
            // DGVTimeSlots
            // 
            DGVTimeSlots.AllowUserToAddRows = false;
            DGVTimeSlots.AllowUserToDeleteRows = false;
            DGVTimeSlots.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DGVTimeSlots.Location = new Point(70, 343);
            DGVTimeSlots.Name = "DGVTimeSlots";
            DGVTimeSlots.ReadOnly = true;
            DGVTimeSlots.RowHeadersWidth = 62;
            DGVTimeSlots.Size = new Size(373, 155);
            DGVTimeSlots.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(149, 55);
            label1.Name = "label1";
            label1.Size = new Size(169, 25);
            label1.TabIndex = 4;
            label1.Text = "Most Popular Hosts";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(149, 315);
            label2.Name = "label2";
            label2.Size = new Size(198, 25);
            label2.TabIndex = 5;
            label2.Text = "Most Popular Timeslots";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(660, 55);
            label3.Name = "label3";
            label3.Size = new Size(226, 25);
            label3.TabIndex = 6;
            label3.Text = "Event Participation Analysis";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(1152, 55);
            label4.Name = "label4";
            label4.Size = new Size(197, 25);
            label4.TabIndex = 7;
            label4.Text = "Event Trends Over Time";
            // 
            // UCeventAnalytics
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(DGVTimeSlots);
            Controls.Add(DGVEventsTrend);
            Controls.Add(DGVParticpation);
            Controls.Add(DGVHosts);
            Name = "UCeventAnalytics";
            Size = new Size(1563, 535);
            ((System.ComponentModel.ISupportInitialize)DGVHosts).EndInit();
            ((System.ComponentModel.ISupportInitialize)DGVParticpation).EndInit();
            ((System.ComponentModel.ISupportInitialize)DGVEventsTrend).EndInit();
            ((System.ComponentModel.ISupportInitialize)DGVTimeSlots).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView DGVHosts;
        private DataGridView DGVParticpation;
        private DataGridView DGVEventsTrend;
        private DataGridView DGVTimeSlots;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
    }
}
