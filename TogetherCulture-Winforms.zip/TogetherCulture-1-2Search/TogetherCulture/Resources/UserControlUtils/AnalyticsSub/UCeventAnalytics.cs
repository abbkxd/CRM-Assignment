﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TogetherCulture.Resources.UserControlUtils.AnalyticsSub
{
    public partial class UCeventAnalytics : UserControl
    {
        public UCeventAnalytics()
        {
            InitializeComponent();
            LoadAnalyticsData();
        }

        private string _connectionString = "Server=localhost;Database=usercred;User Id=root;";


        private void LoadAnalyticsData()
        {
            string connectionString = "your_connection_string_here";

            using (MySqlConnection connection = new MySqlConnection(_connectionString))
            {
                connection.Open();

                
                var hostsQuery = "SELECT HostName, COUNT(*) AS HostCount FROM Events GROUP BY HostName ORDER BY HostCount DESC";
                MySqlDataAdapter adapterHosts = new MySqlDataAdapter(hostsQuery, connection);
                DataTable dtHosts = new DataTable();
                adapterHosts.Fill(dtHosts);
                DGVHosts.DataSource = dtHosts;

                
                var timeslotsQuery = "SELECT EventTime, COUNT(*) AS TimeSlotCount FROM Events GROUP BY EventTime ORDER BY TimeSlotCount DESC";
                MySqlDataAdapter adapterTimeslots = new MySqlDataAdapter(timeslotsQuery, connection);
                DataTable dtTimeslots = new DataTable();
                adapterTimeslots.Fill(dtTimeslots);
                DGVTimeSlots.DataSource = dtTimeslots;

                
                var participantsQuery = "SELECT E.EventName, COUNT(P.Participant_ID) AS ParticipantCount FROM Events E LEFT JOIN Participant P ON E.EventID = P.EventID GROUP BY E.EventName ORDER BY ParticipantCount DESC";
                MySqlDataAdapter adapterParticipants = new MySqlDataAdapter(participantsQuery, connection);
                DataTable dtParticipants = new DataTable();
                adapterParticipants.Fill(dtParticipants);
                DGVParticpation.DataSource = dtParticipants;

                
                var trendsQuery = @"
    SELECT 
        DATE_FORMAT(E.EventDate, '%Y-%m') AS MonthYear,
        COUNT(E.EventID) AS EventsCreated,
        SUM(CASE WHEN P.Participant_ID IS NOT NULL THEN 1 ELSE 0 END) AS Participants
    FROM 
        Events E
    LEFT JOIN 
        Participant P 
    ON 
        E.EventID = P.EventID
    GROUP BY 
        MonthYear
    ORDER BY 
        MonthYear ASC";
                MySqlDataAdapter adapterTrends = new MySqlDataAdapter(trendsQuery, connection);
                DataTable dtTrends = new DataTable();
                adapterTrends.Fill(dtTrends);
                DGVEventsTrend.DataSource = dtTrends;

            }
        }

    }
}
