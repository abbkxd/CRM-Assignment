﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using TogetherCulture.Resources.UserControlUtils.EventsSub;


namespace TogetherCulture.Resources.UserControlUtils
{
    public partial class UserControlEvents : UserControl
    {
        public UserControlEvents()
        {
            InitializeComponent();

        }


        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            UCAddEvents uCAddEvents = new UCAddEvents();

            pnEvent.Controls.Clear();
            pnEvent.Controls.Add(uCAddEvents);
            uCAddEvents.Dock = DockStyle.Fill;
        }

        private void pnAddEvent_Click(object sender, PaintEventArgs e)
        {
            UserControlEvents userControlEvents = new UserControlEvents();

        }

        private void pnManageEvent_Click(object sender, PaintEventArgs e)
        {
            UCManageEvents usermanageEvents = new UCManageEvents();
            pnEvent.Controls.Clear();
            pnEvent.Controls.Add(usermanageEvents);
            usermanageEvents.Dock = DockStyle.Fill;
        }

        private void pnManageEvent_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            UCManageEvents usermanageEvents = new UCManageEvents();
            pnEvent.Controls.Clear();
            pnEvent.Controls.Add(usermanageEvents);
            usermanageEvents.Dock = DockStyle.Fill;
        }
    }

}
