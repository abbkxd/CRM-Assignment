﻿namespace TogetherCulture.Resources.UserControlUtils
{
    partial class UserControlDashBoard
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserControlDashBoard));
            notification = new PictureBox();
            panel1 = new Panel();
            label3 = new Label();
            label2 = new Label();
            upcomming_events = new PictureBox();
            pnl_Dasboard = new Panel();
            Lbl_members = new Label();
            totalmembers = new PictureBox();
            userinteraction = new PictureBox();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)notification).BeginInit();
            ((System.ComponentModel.ISupportInitialize)upcomming_events).BeginInit();
            ((System.ComponentModel.ISupportInitialize)totalmembers).BeginInit();
            ((System.ComponentModel.ISupportInitialize)userinteraction).BeginInit();
            SuspendLayout();
            // 
            // notification
            // 
            notification.Image = (Image)resources.GetObject("notification.Image");
            notification.Location = new Point(945, 56);
            notification.Name = "notification";
            notification.Size = new Size(110, 70);
            notification.SizeMode = PictureBoxSizeMode.Zoom;
            notification.TabIndex = 2;
            notification.TabStop = false;
            notification.Click += notification_Click;
            // 
            // panel1
            // 
            panel1.Location = new Point(879, 151);
            panel1.Name = "panel1";
            panel1.Size = new Size(240, 445);
            panel1.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(65, 220);
            label3.Name = "label3";
            label3.Size = new Size(139, 20);
            label3.TabIndex = 5;
            label3.Text = "Incomming events";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(961, 111);
            label2.Name = "label2";
            label2.Size = new Size(76, 15);
            label2.TabIndex = 6;
            label2.Text = "notifications";
            // 
            // upcomming_events
            // 
            upcomming_events.Image = (Image)resources.GetObject("upcomming_events.Image");
            upcomming_events.Location = new Point(36, 99);
            upcomming_events.Name = "upcomming_events";
            upcomming_events.Size = new Size(204, 150);
            upcomming_events.SizeMode = PictureBoxSizeMode.Zoom;
            upcomming_events.TabIndex = 7;
            upcomming_events.TabStop = false;
            upcomming_events.Click += pictureBox1_Click;
            // 
            // pnl_Dasboard
            // 
            pnl_Dasboard.Location = new Point(18, 255);
            pnl_Dasboard.Name = "pnl_Dasboard";
            pnl_Dasboard.Size = new Size(827, 341);
            pnl_Dasboard.TabIndex = 11;
            pnl_Dasboard.Paint += panel4_Paint;
            // 
            // Lbl_members
            // 
            Lbl_members.AutoSize = true;
            Lbl_members.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Lbl_members.Location = new Point(334, 232);
            Lbl_members.Name = "Lbl_members";
            Lbl_members.Size = new Size(100, 17);
            Lbl_members.TabIndex = 4;
            Lbl_members.Text = "Total members";
            // 
            // totalmembers
            // 
            totalmembers.Image = (Image)resources.GetObject("totalmembers.Image");
            totalmembers.Location = new Point(276, 90);
            totalmembers.Name = "totalmembers";
            totalmembers.Size = new Size(216, 159);
            totalmembers.SizeMode = PictureBoxSizeMode.Zoom;
            totalmembers.TabIndex = 8;
            totalmembers.TabStop = false;
            totalmembers.Click += pictureBox2_Click;
            // 
            // userinteraction
            // 
            userinteraction.Image = (Image)resources.GetObject("userinteraction.Image");
            userinteraction.Location = new Point(554, 90);
            userinteraction.Name = "userinteraction";
            userinteraction.Size = new Size(199, 159);
            userinteraction.SizeMode = PictureBoxSizeMode.Zoom;
            userinteraction.TabIndex = 12;
            userinteraction.TabStop = false;
            userinteraction.Click += userinteraction_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(598, 232);
            label1.Name = "label1";
            label1.Size = new Size(106, 17);
            label1.TabIndex = 0;
            label1.Text = "User Interaction";
            // 
            // UserControlDashBoard
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(Lbl_members);
            Controls.Add(label1);
            Controls.Add(label3);
            Controls.Add(upcomming_events);
            Controls.Add(userinteraction);
            Controls.Add(pnl_Dasboard);
            Controls.Add(label2);
            Controls.Add(panel1);
            Controls.Add(notification);
            Controls.Add(totalmembers);
            Margin = new Padding(2);
            Name = "UserControlDashBoard";
            Size = new Size(1139, 660);
            ((System.ComponentModel.ISupportInitialize)notification).EndInit();
            ((System.ComponentModel.ISupportInitialize)upcomming_events).EndInit();
            ((System.ComponentModel.ISupportInitialize)totalmembers).EndInit();
            ((System.ComponentModel.ISupportInitialize)userinteraction).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private PictureBox notification;
        private Panel panel1;
        private Label label3;
        private Label label2;
        private PictureBox upcomming_events;
        private Panel pnl_Dasboard;
        private Label Lbl_members;
        private PictureBox totalmembers;
        private PictureBox userinteraction;
        private Label label1;
    }
}
