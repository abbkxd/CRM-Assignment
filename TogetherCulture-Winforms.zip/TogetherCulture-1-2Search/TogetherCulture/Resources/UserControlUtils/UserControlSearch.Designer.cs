﻿namespace TogetherCulture.Resources.UserControlUtils
{
    partial class UserControlSearch
    {
        private System.ComponentModel.IContainer components = null;
        private Label lbFname;
        private Label lbLname;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            lbFname = new Label();
            lbLname = new Label();

            SuspendLayout();

            // 
            // lbFname
            // 
            lbFname.AutoSize = true;
            lbFname.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            lbFname.Location = new Point(10, 20);
            lbFname.Name = "lbFname";
            lbFname.Size = new Size(80, 32);
            lbFname.TabIndex = 0;
            lbFname.Text = "FName";

            // 
            // lbLname
            // 
            lbLname.AutoSize = true;
            lbLname.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            lbLname.Location = new Point(200, 20);
            lbLname.Name = "lbLname";
            lbLname.Size = new Size(82, 32);
            lbLname.TabIndex = 1;
            lbLname.Text = "LName";

            // 
            // UserControlSearch
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            Controls.Add(lbFname);
            Controls.Add(lbLname);
            Name = "UserControlSearch";
            Size = new Size(400, 71); // Ensure the size matches the layout
            BorderStyle = BorderStyle.FixedSingle; // Add border for debugging
            ResumeLayout(false);
            PerformLayout();

        }
    }
}