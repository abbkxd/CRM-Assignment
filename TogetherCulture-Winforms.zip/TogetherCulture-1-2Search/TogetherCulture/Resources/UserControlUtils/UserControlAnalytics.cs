﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TogetherCulture.Resources.UserControlUtils.AnalyticsSub;

namespace TogetherCulture.Resources.UserControlUtils
{
    public partial class UserControlAnalytics : UserControl
    {
        public UserControlAnalytics()
        {
            InitializeComponent();
        }

        private void pbUser_Click(object sender, EventArgs e)
        {
            panelAnalytics.Controls.Clear();
            UCuserAnalytics ucuseranalytics = new UCuserAnalytics();
            panelAnalytics.Controls.Add(ucuseranalytics);
            ucuseranalytics.Dock = DockStyle.Fill;
        }

        private void pbEvent_Click(object sender, EventArgs e)
        {
            panelAnalytics.Controls.Clear();
            UCeventAnalytics uceventanalytics = new UCeventAnalytics(); 
            panelAnalytics.Controls.Add(uceventanalytics);
            uceventanalytics.Dock = DockStyle.Fill;
            
        }



        private void pbBooking_Click(object sender, EventArgs e)
        {
            panelAnalytics.Controls.Clear();
            UCbookingAnalytics ucbookinganalytics = new UCbookingAnalytics();
            panelAnalytics.Controls.Add(ucbookinganalytics);
            ucbookinganalytics.Dock = DockStyle.Fill;
        }
    }
}
