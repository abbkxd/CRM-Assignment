﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TogetherCulture.Resources.UserControlUtils.MembershipSub;

namespace TogetherCulture.Resources.UserControlUtils
{
    public partial class UserControlMembership : UserControl
    {
        public UserControlMembership()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Pnl_Memberdetails.Controls.Clear();

           
            ViewMemberDetails viewMemberDetails = new ViewMemberDetails();

            
            Pnl_Memberdetails.Controls.Add(viewMemberDetails);
            viewMemberDetails.Dock = DockStyle.Fill;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Pnl_Memberdetails.Controls.Clear();

           
            AddMember Addmem = new AddMember();

           
            Pnl_Memberdetails.Controls.Add(Addmem);
            Addmem.Dock = DockStyle.Fill;
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Pnl_Memberdetails_Paint(object sender, PaintEventArgs e)
        {

        }

        private void lbl_Memberdtls_Click(object sender, EventArgs e)
        {

        }
    }
}
