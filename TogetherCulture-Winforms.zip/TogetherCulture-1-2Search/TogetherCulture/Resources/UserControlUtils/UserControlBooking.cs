﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TogetherCulture.Resources.UserControlUtils.BookingSub;

namespace TogetherCulture.Resources.UserControlUtils.EventsSub
{
    public partial class UserControlBooking : UserControl
    {
        public UserControlBooking()
        {
            InitializeComponent();
        }

        

        private void pbManageBooking_Click(object sender, EventArgs e)
        {
            pnBookingUserControl.Controls.Clear();
            ucManageBooking ucMBooking = new ucManageBooking();
            pnBookingUserControl.Controls.Add(ucMBooking);
            ucMBooking.Dock = DockStyle.Fill;
        }

        private void pbViewBooking_Click(object sender, EventArgs e)
        {
            pnBookingUserControl.Controls.Clear();
            ucViewBooking ucVBooking = new ucViewBooking();
            pnBookingUserControl.Controls.Add(ucVBooking);
            ucVBooking.Dock = DockStyle.Fill;
        }
    }
}
