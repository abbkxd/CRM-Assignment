﻿namespace TogetherCulture.Resources.UserControlUtils
{
    partial class UserControlMembership
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserControlMembership));
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            Pnl_MemDetails = new Panel();
            Pnl_AddMembers = new Panel();
            Pnl_Memberdetails = new Panel();
            lbl_Memberdtls = new Label();
            lbl_Addmembrs = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            Pnl_MemDetails.SuspendLayout();
            Pnl_AddMembers.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(13, 33);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(201, 137);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(33, 33);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(201, 137);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 3;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // Pnl_MemDetails
            // 
            Pnl_MemDetails.Controls.Add(pictureBox1);
            Pnl_MemDetails.Controls.Add(lbl_Memberdtls);
            Pnl_MemDetails.Location = new Point(163, 48);
            Pnl_MemDetails.Name = "Pnl_MemDetails";
            Pnl_MemDetails.Size = new Size(255, 201);
            Pnl_MemDetails.TabIndex = 5;
            // 
            // Pnl_AddMembers
            // 
            Pnl_AddMembers.Controls.Add(lbl_Addmembrs);
            Pnl_AddMembers.Controls.Add(pictureBox2);
            Pnl_AddMembers.Location = new Point(640, 48);
            Pnl_AddMembers.Name = "Pnl_AddMembers";
            Pnl_AddMembers.Size = new Size(255, 201);
            Pnl_AddMembers.TabIndex = 6;
            Pnl_AddMembers.Paint += panel2_Paint;
            // 
            // Pnl_Memberdetails
            // 
            Pnl_Memberdetails.Location = new Point(13, 280);
            Pnl_Memberdetails.Name = "Pnl_Memberdetails";
            Pnl_Memberdetails.Size = new Size(1110, 348);
            Pnl_Memberdetails.TabIndex = 7;
            Pnl_Memberdetails.Paint += Pnl_Memberdetails_Paint;
            // 
            // lbl_Memberdtls
            // 
            lbl_Memberdtls.AutoSize = true;
            lbl_Memberdtls.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_Memberdtls.Location = new Point(62, 173);
            lbl_Memberdtls.Name = "lbl_Memberdtls";
            lbl_Memberdtls.Size = new Size(106, 15);
            lbl_Memberdtls.TabIndex = 8;
            lbl_Memberdtls.Text = "MEMBER DETAILS";
            lbl_Memberdtls.Click += lbl_Memberdtls_Click;
            // 
            // lbl_Addmembrs
            // 
            lbl_Addmembrs.AutoSize = true;
            lbl_Addmembrs.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_Addmembrs.Location = new Point(90, 173);
            lbl_Addmembrs.Name = "lbl_Addmembrs";
            lbl_Addmembrs.Size = new Size(93, 15);
            lbl_Addmembrs.TabIndex = 9;
            lbl_Addmembrs.Text = "ADD MEMBERS";
            // 
            // UserControlMembership
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(Pnl_Memberdetails);
            Controls.Add(Pnl_AddMembers);
            Controls.Add(Pnl_MemDetails);
            Margin = new Padding(2);
            Name = "UserControlMembership";
            Size = new Size(1139, 660);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            Pnl_MemDetails.ResumeLayout(false);
            Pnl_MemDetails.PerformLayout();
            Pnl_AddMembers.ResumeLayout(false);
            Pnl_AddMembers.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private Panel Pnl_MemDetails;
        private Panel Pnl_AddMembers;
        private Panel Pnl_Memberdetails;
        private Label lbl_Memberdtls;
        private Label lbl_Addmembrs;
    }
}
