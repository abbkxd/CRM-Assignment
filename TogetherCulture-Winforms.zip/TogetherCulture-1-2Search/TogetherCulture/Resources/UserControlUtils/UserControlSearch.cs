﻿using System;
using System.Drawing;
using System.Windows.Forms;
using TogetherCulture.Resources.ClassUtils;

namespace TogetherCulture.Resources.UserControlUtils
{
    public partial class UserControlSearch : UserControl
    {
        public UserControlSearch()
        {
            InitializeComponent();

            this.Size = new Size(400, 71); 
            this.Visible = true;
            this.BorderStyle = BorderStyle.FixedSingle;

        }

        public void details(SearchClass SC)
        {
            try
            {
                Console.WriteLine($"Setting details: FName = {SC.Fname}, LName = {SC.Lname}");
                lbFname.Text = SC.Fname;
                lbLname.Text = SC.Lname;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error setting UserControlSearch details: {ex.Message}");
            }
        }
    }
}