﻿namespace TogetherCulture.Resources
{
    partial class FormSignup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lbUsername = new Label();
            lbEmail = new Label();
            label3 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            btSignup = new Button();
            btLogin = new Button();
            label1 = new Label();
            cbTCSignup = new CheckBox();
            linkLabelTC = new LinkLabel();
            SuspendLayout();
            // 
            // lbUsername
            // 
            lbUsername.AutoSize = true;
            lbUsername.Location = new Point(80, 107);
            lbUsername.Name = "lbUsername";
            lbUsername.Size = new Size(91, 25);
            lbUsername.TabIndex = 0;
            lbUsername.Text = "Username";
            // 
            // lbEmail
            // 
            lbEmail.AutoSize = true;
            lbEmail.Location = new Point(113, 218);
            lbEmail.Name = "lbEmail";
            lbEmail.Size = new Size(54, 25);
            lbEmail.TabIndex = 1;
            lbEmail.Text = "Email";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(80, 166);
            label3.Name = "label3";
            label3.Size = new Size(87, 25);
            label3.TabIndex = 2;
            label3.Text = "Password";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(205, 107);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(150, 31);
            textBox1.TabIndex = 3;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(205, 160);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(150, 31);
            textBox2.TabIndex = 4;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(205, 212);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(150, 31);
            textBox3.TabIndex = 5;
            // 
            // btSignup
            // 
            btSignup.Location = new Point(178, 346);
            btSignup.Name = "btSignup";
            btSignup.Size = new Size(112, 34);
            btSignup.TabIndex = 6;
            btSignup.Text = "Signup";
            btSignup.UseVisualStyleBackColor = true;
            btSignup.Click += btSignup_Click;
            // 
            // btLogin
            // 
            btLogin.Location = new Point(595, 190);
            btLogin.Name = "btLogin";
            btLogin.Size = new Size(112, 34);
            btLogin.TabIndex = 7;
            btLogin.Text = "Login";
            btLogin.UseVisualStyleBackColor = true;
            btLogin.Click += btLogin_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(583, 138);
            label1.Name = "label1";
            label1.Size = new Size(143, 25);
            label1.TabIndex = 8;
            label1.Text = "Have an account";
            // 
            // cbTCSignup
            // 
            cbTCSignup.AutoSize = true;
            cbTCSignup.Location = new Point(153, 294);
            cbTCSignup.Name = "cbTCSignup";
            cbTCSignup.Size = new Size(22, 21);
            cbTCSignup.TabIndex = 10;
            cbTCSignup.UseVisualStyleBackColor = true;
            cbTCSignup.CheckedChanged += cbTCSignup_CheckedChanged;
            // 
            // linkLabelTC
            // 
            linkLabelTC.AutoSize = true;
            linkLabelTC.Location = new Point(181, 290);
            linkLabelTC.Name = "linkLabelTC";
            linkLabelTC.Size = new Size(243, 25);
            linkLabelTC.TabIndex = 11;
            linkLabelTC.TabStop = true;
            linkLabelTC.Text = "Accept terms and conditions.";
            linkLabelTC.LinkClicked += linkLabelTC_LinkClicked;
            // 
            // FormSignup
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(linkLabelTC);
            Controls.Add(cbTCSignup);
            Controls.Add(label1);
            Controls.Add(btLogin);
            Controls.Add(btSignup);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(label3);
            Controls.Add(lbEmail);
            Controls.Add(lbUsername);
            Name = "FormSignup";
            Text = "FormSignup";
            Load += FormSignup_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbUsername;
        private Label lbEmail;
        private Label label3;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private Button btSignup;
        private Button btLogin;
        private Label label1;
        private CheckBox cbTCSignup;
        private LinkLabel linkLabelTC;
    }
}