﻿using System;
using MySql.Data.MySqlClient; //SQL
using System.Security.Cryptography;// for hashing
using System.Text;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;


namespace TogetherCulture.Resources
{
    public partial class FormSignup : Form
    {

        private readonly string _connectionString = "Server=localhost;Database=usercred;User Id=root;";


        public FormSignup()
        {
            InitializeComponent();
            this.cbTCSignup.CheckedChanged += new System.EventHandler(this.cbTCSignup_CheckedChanged);

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btSignup_Click(object sender, EventArgs e)
        {
            string username = textBox1.Text;
            string password = textBox2.Text;
            string email = textBox3.Text;

            if (SaveUser(username, password, email))
            {
                MessageBox.Show("Account created successfully!");
                this.Hide();

                string Usernamefkey = username;
                Userinfo Personaldetails = new Userinfo(Usernamefkey);

                Personaldetails.Show();

            }
            else
            {
                MessageBox.Show("An error occurred while creating the account.");
            }

        }

        private bool SaveUser(string username, string password, string email)
        {
            // Hash the password using SHA-256
            string passwordHash = ComputeSha256Hash(password);

            try
            {
                using (MySqlConnection connection = new MySqlConnection(_connectionString))
                {
                    connection.Open();
                    string query = "INSERT INTO Users (Username, PasswordHash, Email) VALUES (@username, @passwordHash, @email)";

                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@username", username);
                        command.Parameters.AddWithValue("@passwordHash", passwordHash);
                        command.Parameters.AddWithValue("@email", email);
                        command.ExecuteNonQuery();
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                return false;
            }
        }

        private static string ComputeSha256Hash(string rawData)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(rawData));
                StringBuilder builder = new StringBuilder();
                foreach (byte b in bytes)
                {
                    builder.Append(b.ToString("x2"));
                }
                return builder.ToString();
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void FormSignup_Load(object sender, EventArgs e)
        {
            btSignup.Enabled = false;
        }

        private void cbTCSignup_CheckedChanged(object sender, EventArgs e)
        {
            btSignup.Enabled = cbTCSignup.Checked;
        }

        private void btLogin_Click(object sender, EventArgs e)
        {
            FormLogin btSignup = new FormLogin();
            this.Hide();
            btSignup.Show();
        }

        private void linkLabelTC_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.linkLabelTC.LinkVisited = true;
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
            {
                FileName = "https://www.togetherculture.com",
                UseShellExecute = true
            });


        }
    }
}
