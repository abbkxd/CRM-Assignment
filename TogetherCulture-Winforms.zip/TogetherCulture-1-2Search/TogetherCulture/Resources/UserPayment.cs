﻿using MySql.Data.MySqlClient;
using System;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace TogetherCulture.Resources
{
    public partial class UserPayment : Form
    {
        private string _usernamefk;
        private string _storedSubValue;
        private readonly string _connectionString = "Server=localhost;Database=usercred;User Id=root;";
        private string _cardType;

        public UserPayment(string username, string storedSubValue)
        {
            InitializeComponent();
            _usernamefk = username;
            _storedSubValue = storedSubValue;
        }

        private void rBVisa_CheckedChanged(object sender, EventArgs e)
        {
            if (rBVisa.Checked)
            {
                _cardType = "Visa Card";
            }
        }

        private void rbMCard_CheckedChanged(object sender, EventArgs e)
        {
            if (rbMCard.Checked)
            {
                _cardType = "MasterCard";
            }
        }

        private bool SaveSubscriptionDetails(string SubID, string username, string subscriptionType, DateTime SubDate)
        {
            SubDate = DateTime.Now;

            try
            {
                using (MySqlConnection connection = new MySqlConnection(_connectionString))
                {
                    connection.Open();
                    string query = "INSERT INTO usersubscription (SubID, Username, SubscriptionType, SubDate) " +
                                   "VALUES (@SubID, @Username, @SubscriptionType, @SubDate)";

                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@SubID", SubID);
                        command.Parameters.AddWithValue("@Username", username);
                        command.Parameters.AddWithValue("@SubscriptionType", subscriptionType);
                        command.Parameters.AddWithValue("@SubDate", SubDate);
                        command.ExecuteNonQuery();
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                return false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string Username = _usernamefk;
            string CardHolderName = tbCardName.Text;
            string CardNo = tbCardNo.Text; 
            int cvv;
            DateTime Expiryno = DTCard.Value;

            
            if (!int.TryParse(tbCVV.Text, out cvv))
            {
                MessageBox.Show("Invalid CVV. It must be a numeric value.");
                return;
            }

            
            if (!Regex.IsMatch(CardNo, @"^\d{16}$"))
            {
                MessageBox.Show("Card number must be exactly 16 digits.");
                return;
            }

            
            if (string.IsNullOrWhiteSpace(CardHolderName) || string.IsNullOrWhiteSpace(CardNo) || string.IsNullOrWhiteSpace(tbCVV.Text))
            {
                MessageBox.Show("Please fill in all required fields.");
                return;
            }

            
            if (string.IsNullOrEmpty(_cardType))
            {
                MessageBox.Show("Please select a card type.");
                return;
            }

            
            string SubID = EntityID.GenerateId("SubID");
            string PaymentID = EntityID.GenerateId("PAYID");
            bool success = SaveCardinfo(PaymentID, Username, CardHolderName, CardNo, cvv, Expiryno, _cardType);

            if (success)
            {
                MessageBox.Show("Payment information saved successfully.");

                bool subscriptionSaved = SaveSubscriptionDetails(SubID, _usernamefk, _storedSubValue, DateTime.Now);

                Usertags usertags = new Usertags(Username);
                this.Hide();
                usertags.Show();
            }
            else
            {
                MessageBox.Show("Failed to save payment information.");
            }
        }

        private bool SaveCardinfo(string PaymentID, string Username, string CardHolderName, string CardNo, int cvv, DateTime Expiryno, string CardType)
        {
            try
            {
                using (MySqlConnection connection = new MySqlConnection(_connectionString))
                {
                    connection.Open();
                    string query = "INSERT INTO payments (PaymentID, Username, CardHolderName, CardNo, CVV, ExpiryNo, CardType) " +
                                   "VALUES (@PaymentID, @Username, @CardHolderName, @CardNo, @CVV, @ExpiryNo, @CardType)";

                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@PaymentID", PaymentID);
                        command.Parameters.AddWithValue("@Username", Username);
                        command.Parameters.AddWithValue("@CardHolderName", CardHolderName);
                        command.Parameters.AddWithValue("@CardNo", CardNo);
                        command.Parameters.AddWithValue("@CVV", cvv);
                        command.Parameters.AddWithValue("@ExpiryNo", Expiryno);
                        command.Parameters.AddWithValue("@CardType", CardType);
                        command.ExecuteNonQuery();
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                return false;
            }
        }

        private void UserPayment_Load(object sender, EventArgs e)
        {
        }
    }
}
