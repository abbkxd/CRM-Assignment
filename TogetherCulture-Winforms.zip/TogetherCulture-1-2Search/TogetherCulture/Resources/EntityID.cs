﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace TogetherCulture.Resources
{
    public class EntityID
    {
        public static string GenerateId(string prefix = null)
        {
            string timestamp = DateTime.UtcNow.ToString("yyyyMMddHHmmssfff");
            string guid = Guid.NewGuid().ToString("N").Substring(0, 8);
            return $"{prefix?.ToUpper()}-{timestamp}-{guid}";
        }

    }
    
}
