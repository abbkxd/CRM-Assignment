﻿using Microsoft.VisualBasic;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace TogetherCulture.Resources
{
    public partial class Usertags : Form
    {
        private string _usernamefk;
        private readonly string _connectionString = "Server=localhost;Database=usercred;User Id=root;";
        public Usertags(string username)
        {
            InitializeComponent();
            _usernamefk = username;
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {







        }

        private void btSubmit_Click(object sender, EventArgs e)
        {

            List<string> checkedItems = new List<string>();

            foreach (var item in checkedListBox1.CheckedItems)
            {
                checkedItems.Add(item.ToString());

            }


            UpdateUserInterests(_usernamefk, checkedItems);
        }

        private void UpdateUserInterests(string username, List<string> interests)
        {
            try
            {
                using (MySqlConnection connection = new MySqlConnection(_connectionString))
                {
                    connection.Open();
                    string query = "INSERT INTO user_interests (username, interest_tag) " +
                                   "VALUES (@username, @interest)";

                    foreach (string interest in interests)
                    {
                        using (MySqlCommand command = new MySqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@username", username);
                            command.Parameters.AddWithValue("@interest", interest);

                            command.ExecuteNonQuery();
                        }
                    }

                    this.Close();


                    FormLogin loginForm = new FormLogin();
                    loginForm.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }


        private void Usertags_Load(object sender, EventArgs e)
        {

        }
    }
}




        
            




        
