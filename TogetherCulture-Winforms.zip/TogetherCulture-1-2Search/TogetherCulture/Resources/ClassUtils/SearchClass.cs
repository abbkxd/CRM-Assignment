﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace TogetherCulture.Resources.ClassUtils
{
    public class SearchClass
    {
        private readonly string _connectionString = "Server=localhost;Database=usercred;User Id=root;";
        public string Fname { get; set; }
        public string Lname { get; set; }

        public static List<SearchClass> list = new List<SearchClass>();

        public void search(string key)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(_connectionString))
                {
                    conn.Open();
                    string sql = "SELECT FName, LName FROM userinfo WHERE FName LIKE @key OR LName LIKE @key";
                    using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@key", key + "%");

                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            list.Clear();

                            while (reader.Read())
                            {
                                var fname = reader["FName"].ToString();
                                var lname = reader["LName"].ToString();

                                
                                Console.WriteLine($"Database Result: FName = {fname}, LName = {lname}");

                                SearchClass data = new SearchClass()
                                {
                                    Fname = fname,
                                    Lname = lname
                                };
                                list.Add(data);
                            }

                            
                            Console.WriteLine($"Total results retrieved: {list.Count}");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error fetching search results: {ex.Message}");
            }
        }
    }
}