﻿namespace TogetherCulture
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Panel panelSideMenu;
        private System.Windows.Forms.Panel panelLogo;
        private System.Windows.Forms.Button btnDashboard;
        private System.Windows.Forms.Button btnMembership;
        private System.Windows.Forms.Button btnAnalytics;
        private System.Windows.Forms.Button btLogout;
        private System.Windows.Forms.Label labelAppName;
        private System.Windows.Forms.PictureBox pictureLogo;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            panelSideMenu = new Panel();
            btBooking = new Button();
            btEvents = new Button();
            btLogout = new Button();
            btnAnalytics = new Button();
            btnMembership = new Button();
            btnDashboard = new Button();
            panelLogo = new Panel();
            labelAppName = new Label();
            pictureLogo = new PictureBox();
            panel1 = new Panel();
            pnSearch = new Panel();
            pictureBox1 = new PictureBox();
            tbSearch = new TextBox();
            FLWSearch = new FlowLayoutPanel();
            panelMain = new Panel();
            panelSideMenu.SuspendLayout();
            panelLogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureLogo).BeginInit();
            pnSearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panelMain.SuspendLayout();
            SuspendLayout();
            // 
            // panelSideMenu
            // 
            panelSideMenu.BackColor = Color.FromArgb(40, 45, 51);
            panelSideMenu.Controls.Add(btBooking);
            panelSideMenu.Controls.Add(btEvents);
            panelSideMenu.Controls.Add(btLogout);
            panelSideMenu.Controls.Add(btnAnalytics);
            panelSideMenu.Controls.Add(btnMembership);
            panelSideMenu.Controls.Add(btnDashboard);
            panelSideMenu.Controls.Add(panelLogo);
            panelSideMenu.Dock = DockStyle.Left;
            panelSideMenu.Location = new Point(0, 0);
            panelSideMenu.Margin = new Padding(4, 3, 4, 3);
            panelSideMenu.Name = "panelSideMenu";
            panelSideMenu.Size = new Size(257, 660);
            panelSideMenu.TabIndex = 0;
            // 
            // btBooking
            // 
            btBooking.Dock = DockStyle.Top;
            btBooking.FlatStyle = FlatStyle.Flat;
            btBooking.ForeColor = Color.White;
            btBooking.Location = new Point(0, 312);
            btBooking.Margin = new Padding(4, 3, 4, 3);
            btBooking.Name = "btBooking";
            btBooking.Size = new Size(257, 52);
            btBooking.TabIndex = 6;
            btBooking.Text = "Booking";
            btBooking.UseVisualStyleBackColor = true;
            btBooking.Click += button2_Click;
            // 
            // btEvents
            // 
            btEvents.Dock = DockStyle.Top;
            btEvents.FlatStyle = FlatStyle.Flat;
            btEvents.ForeColor = Color.White;
            btEvents.Location = new Point(0, 260);
            btEvents.Margin = new Padding(4, 3, 4, 3);
            btEvents.Name = "btEvents";
            btEvents.Size = new Size(257, 52);
            btEvents.TabIndex = 5;
            btEvents.Text = "Events";
            btEvents.UseVisualStyleBackColor = true;
            btEvents.Click += btEvents_Click_1;
            // 
            // btLogout
            // 
            btLogout.Dock = DockStyle.Bottom;
            btLogout.FlatStyle = FlatStyle.Flat;
            btLogout.ForeColor = Color.White;
            btLogout.Location = new Point(0, 608);
            btLogout.Margin = new Padding(4, 3, 4, 3);
            btLogout.Name = "btLogout";
            btLogout.Size = new Size(257, 52);
            btLogout.TabIndex = 4;
            btLogout.Text = "Logout";
            btLogout.UseVisualStyleBackColor = true;
            btLogout.Click += btLogout_Click;
            // 
            // btnAnalytics
            // 
            btnAnalytics.Dock = DockStyle.Top;
            btnAnalytics.FlatStyle = FlatStyle.Flat;
            btnAnalytics.ForeColor = Color.White;
            btnAnalytics.Location = new Point(0, 208);
            btnAnalytics.Margin = new Padding(4, 3, 4, 3);
            btnAnalytics.Name = "btnAnalytics";
            btnAnalytics.Size = new Size(257, 52);
            btnAnalytics.TabIndex = 3;
            btnAnalytics.Text = "Analytics";
            btnAnalytics.UseVisualStyleBackColor = true;
            btnAnalytics.Click += btnAnalytics_Click;
            // 
            // btnMembership
            // 
            btnMembership.Dock = DockStyle.Top;
            btnMembership.FlatStyle = FlatStyle.Flat;
            btnMembership.ForeColor = Color.White;
            btnMembership.Location = new Point(0, 156);
            btnMembership.Margin = new Padding(4, 3, 4, 3);
            btnMembership.Name = "btnMembership";
            btnMembership.Size = new Size(257, 52);
            btnMembership.TabIndex = 2;
            btnMembership.Text = "Membership";
            btnMembership.UseVisualStyleBackColor = true;
            btnMembership.Click += btnMembership_Click;
            // 
            // btnDashboard
            // 
            btnDashboard.Dock = DockStyle.Top;
            btnDashboard.FlatStyle = FlatStyle.Flat;
            btnDashboard.ForeColor = Color.White;
            btnDashboard.Location = new Point(0, 104);
            btnDashboard.Margin = new Padding(4, 3, 4, 3);
            btnDashboard.Name = "btnDashboard";
            btnDashboard.Size = new Size(257, 52);
            btnDashboard.TabIndex = 1;
            btnDashboard.Text = "Dashboard";
            btnDashboard.UseVisualStyleBackColor = true;
            btnDashboard.Click += btnDashboard_Click;
            // 
            // panelLogo
            // 
            panelLogo.BackColor = Color.FromArgb(40, 45, 51);
            panelLogo.Controls.Add(labelAppName);
            panelLogo.Controls.Add(pictureLogo);
            panelLogo.Dock = DockStyle.Top;
            panelLogo.Location = new Point(0, 0);
            panelLogo.Margin = new Padding(4, 3, 4, 3);
            panelLogo.Name = "panelLogo";
            panelLogo.Size = new Size(257, 104);
            panelLogo.TabIndex = 0;
            // 
            // labelAppName
            // 
            labelAppName.AutoSize = true;
            labelAppName.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            labelAppName.ForeColor = Color.White;
            labelAppName.Location = new Point(93, 40);
            labelAppName.Margin = new Padding(4, 0, 4, 0);
            labelAppName.Name = "labelAppName";
            labelAppName.Size = new Size(138, 21);
            labelAppName.TabIndex = 1;
            labelAppName.Text = "Together Culture";
            // 
            // pictureLogo
            // 
            pictureLogo.Location = new Point(12, 21);
            pictureLogo.Margin = new Padding(4, 3, 4, 3);
            pictureLogo.Name = "pictureLogo";
            pictureLogo.Size = new Size(75, 74);
            pictureLogo.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureLogo.TabIndex = 0;
            pictureLogo.TabStop = false;
            // 
            // panel1
            // 
            panel1.Location = new Point(6, 130);
            panel1.Margin = new Padding(2);
            panel1.Name = "panel1";
            panel1.Size = new Size(1084, 527);
            panel1.TabIndex = 0;
            // 
            // pnSearch
            // 
            pnSearch.BackColor = Color.White;
            pnSearch.Controls.Add(pictureBox1);
            pnSearch.Controls.Add(tbSearch);
            pnSearch.Location = new Point(340, 17);
            pnSearch.Margin = new Padding(2);
            pnSearch.Name = "pnSearch";
            pnSearch.Size = new Size(420, 43);
            pnSearch.TabIndex = 1;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.FromArgb(36, 146, 255);
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(349, 0);
            pictureBox1.Margin = new Padding(2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(70, 43);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // tbSearch
            // 
            tbSearch.BackColor = Color.White;
            tbSearch.BorderStyle = BorderStyle.None;
            tbSearch.Cursor = Cursors.IBeam;
            tbSearch.ForeColor = SystemColors.InactiveBorder;
            tbSearch.Location = new Point(2, 11);
            tbSearch.Margin = new Padding(2);
            tbSearch.Name = "tbSearch";
            tbSearch.PlaceholderText = "Search";
            tbSearch.ScrollBars = ScrollBars.Vertical;
            tbSearch.Size = new Size(344, 16);
            tbSearch.TabIndex = 1;
            tbSearch.TextChanged += textBox1_TextChanged;
            // 
            // FLWSearch
            // 
            FLWSearch.Location = new Point(342, 63);
            FLWSearch.Margin = new Padding(2);
            FLWSearch.Name = "FLWSearch";
            FLWSearch.Size = new Size(351, 63);
            FLWSearch.TabIndex = 2;
            FLWSearch.Paint += FLWSearch_Paint;
            // 
            // panelMain
            // 
            panelMain.BackColor = Color.FromArgb(222, 215, 215);
            panelMain.Controls.Add(FLWSearch);
            panelMain.Controls.Add(pnSearch);
            panelMain.Controls.Add(panel1);
            panelMain.Dock = DockStyle.Fill;
            panelMain.Location = new Point(257, 0);
            panelMain.Margin = new Padding(4, 3, 4, 3);
            panelMain.Name = "panelMain";
            panelMain.Size = new Size(1101, 660);
            panelMain.TabIndex = 1;
            panelMain.Paint += panelMain_Paint;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImageLayout = ImageLayout.None;
            ClientSize = new Size(1358, 660);
            Controls.Add(panelMain);
            Controls.Add(panelSideMenu);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(4, 3, 4, 3);
            Name = "Form1";
            Text = "Together Culture";
            panelSideMenu.ResumeLayout(false);
            panelLogo.ResumeLayout(false);
            panelLogo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureLogo).EndInit();
            pnSearch.ResumeLayout(false);
            pnSearch.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panelMain.ResumeLayout(false);
            ResumeLayout(false);
        }

        private Button btBooking;
        private Button btEvents;
        public Panel panel1;
        private Panel pnSearch;
        private PictureBox pictureBox1;
        private TextBox tbSearch;
        private FlowLayoutPanel FLWSearch;
        private Panel panelMain;
    }
}