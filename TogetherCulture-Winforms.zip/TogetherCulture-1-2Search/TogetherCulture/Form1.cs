using System;
using System.Drawing;
using System.Windows.Forms;
using TogetherCulture.Resources;
using TogetherCulture.Resources.ClassUtils;
using TogetherCulture.Resources.UserControlUtils;
using TogetherCulture.Resources.UserControlUtils.EventsSub;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace TogetherCulture
{
    public partial class Form1 : Form
    {

        Resources.UserControlUtils.UserControlDashBoard ucdashboard = new Resources.UserControlUtils.UserControlDashBoard();
        Resources.UserControlUtils.UserControlMembership ucmembership = new Resources.UserControlUtils.UserControlMembership();
        Resources.UserControlUtils.UserControlAnalytics ucanalytics = new Resources.UserControlUtils.UserControlAnalytics();
        Resources.UserControlUtils.UserControlSettings ucsetting = new Resources.UserControlUtils.UserControlSettings();
        Resources.UserControlUtils.UserControlEvents ucevents = new Resources.UserControlUtils.UserControlEvents();
        UserControlBooking ucbooking = new UserControlBooking();

        








        public Form1(string username)
        {
            InitializeComponent();
            panel1.Controls.Clear();
            panel1.Controls.Add(ucdashboard);
            ucdashboard.Dock = DockStyle.Fill;


            FormBorderStyle = FormBorderStyle.None;
            WindowState = FormWindowState.Maximized;

            
            FLWSearch = new FlowLayoutPanel
            {
                Location = new Point(20, 100),
                Size = new Size(488, 105),
                FlowDirection = FlowDirection.TopDown,
                AutoScroll = true,
                WrapContents = false,
                BackColor = Color.LightGray,
                Name = "FLWSearch"
            };

            
            panelMain.Controls.Add(FLWSearch);
        }

        private void loadDetails()
        {
            try
            {
                
                FLWSearch.Controls.Clear();


                if (SearchClass.list.Count == 0)
                {
                    MessageBox.Show("No results found.");
                    return;
                }

                
                foreach (SearchClass data in SearchClass.list)
                {
                    Console.WriteLine($"Adding result: FName = {data.Fname}, LName = {data.Lname}");

                    
                    UserControlSearch res = new UserControlSearch();
                    res.details(data);

                    
                    Console.WriteLine($"UserControlSearch: Name = {res.Name}, Visible = {res.Visible}, Size = {res.Size}");

                    FLWSearch.Controls.Add(res);
                }

                
                FLWSearch.Height = Math.Max(FLWSearch.Controls.Count * 71, 38);
                FLWSearch.Visible = true;
                FLWSearch.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading search results: {ex.Message}");
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            tbSearch.ForeColor = Color.Black;



            try
            {
                if (tbSearch.TextLength >= 1)
                {
                    FLWSearch.Controls.Clear();
                    SearchClass.list.Clear();

                    SearchClass searchInstance = new SearchClass();
                    searchInstance.search(tbSearch.Text);

                    loadDetails();
                }
                else
                {
                    FLWSearch.Controls.Clear();
                    FLWSearch.Height = 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error during search: {ex.Message}");
            }
        }



        private void btEvents_Click_1(object sender, EventArgs e)
        {

            panel1.Controls.Clear();

            panelMain.Controls.Clear();
            panelMain.Controls.Add(pnSearch); 
            panelMain.Controls.Add(ucevents);



            
            pnSearch.BringToFront(); 
            ucevents.Dock = DockStyle.Fill;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            panelMain.Controls.Clear();
            panelMain.Controls.Add(pnSearch);
            panelMain.Controls.Add(ucbooking);
            pnSearch.BringToFront(); 
            ucbooking.Dock = DockStyle.Fill;
        }

        private void btnDashboard_Click(object sender, EventArgs e)
        {
            panelMain.Controls.Clear();
            panelMain.Controls.Add(pnSearch); 
            panelMain.Controls.Add(ucdashboard); 
            pnSearch.BringToFront(); 
            ucevents.Dock = DockStyle.Fill;
        }

        private void btnMembership_Click(object sender, EventArgs e)
        {
            panelMain.Controls.Clear();
            panelMain.Controls.Add(pnSearch); 
            panelMain.Controls.Add(ucmembership); 
            pnSearch.BringToFront(); 
            ucevents.Dock = DockStyle.Fill;
        }

        private void btnAnalytics_Click(object sender, EventArgs e)
        {
            panelMain.Controls.Clear();
            panelMain.Controls.Add(pnSearch); 
            panelMain.Controls.Add(ucanalytics);
            pnSearch.BringToFront(); 
            ucevents.Dock = DockStyle.Fill;
        }

        private void btLogout_Click(object sender, EventArgs e)
        {
            this.Close();
            FormLogin formLogin = new FormLogin();
            formLogin.Show();


        }

        private void FLWSearch_Paint(object sender, PaintEventArgs e)
        {
            Enabled = tbSearch.Enabled;
        }

        private void panelMain_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            panelMain.Controls.Clear();
            panelMain.Controls.Add(pnSearch);
            panelMain.Controls.Add(ucsetting); 
            pnSearch.BringToFront(); 
            ucevents.Dock = DockStyle.Fill;
        }
    }
}

